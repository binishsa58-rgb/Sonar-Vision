"""check_backend.py - health check for a backend module against the frozen contract.

Usage:
    python check_backend.py backend_stub
    python check_backend.py adapter

It feeds one fake camera image to process_frame() and checks every key and
type from the contract, then checks that speak() and a None frame never
crash. Everything prints PASS / FAIL in plain English.

Note: checking "adapter" loads the real models (YOLO + Depth Anything),
which downloads ~100 MB the very first time and can take a minute or two.
It never touches the TinyFish API and never prints your API key.
"""

import importlib
import sys

import numpy as np

REQUIRED_KEYS = ["depth_vis", "zones", "level", "message", "tone"]
LEVELS = {"clear", "caution", "danger"}


def _is_audio(value):
    """A tone/speech value must be (sample_rate, numpy samples) or None."""
    return (
        isinstance(value, tuple)
        and len(value) == 2
        and isinstance(value[0], int)
        and isinstance(value[1], np.ndarray)
    )


def main():
    module_name = sys.argv[1] if len(sys.argv) > 1 else "backend_stub"
    print(f"Checking backend module: {module_name}")
    print("-" * 60)

    failures = 0

    def check(name, ok, detail=""):
        nonlocal failures
        if ok:
            print(f"PASS  {name}")
        else:
            failures += 1
            print(f"FAIL  {name}  {detail}")

    try:
        backend = importlib.import_module(module_name)
        check(f"import {module_name}", True)
    except Exception as e:
        print(f"FAIL  import {module_name}: {type(e).__name__}: {e}")
        raise SystemExit(1)

    check("process_frame exists", callable(getattr(backend, "process_frame", None)))
    check("speak exists", callable(getattr(backend, "speak", None)))

    # A fake camera image: dark blob on the left, bright on the right.
    frame = np.full((480, 640, 3), 220, dtype=np.uint8)
    frame[:, :320] = 20

    try:
        result = backend.process_frame(frame)
        check("process_frame(frame) runs", True)
    except Exception as e:
        check("process_frame(frame) runs", False, f"({type(e).__name__}: {e})")
        result = None

    if isinstance(result, dict):
        for key in REQUIRED_KEYS:
            check(f"result has key '{key}'", key in result)

        depth = result.get("depth_vis")
        check(
            "depth_vis is a uint8 HxWx3 image",
            isinstance(depth, np.ndarray)
            and depth.dtype == np.uint8
            and depth.ndim == 3
            and depth.shape[2] == 3,
            f"got {type(depth).__name__}"
            + (f" {depth.dtype} {depth.shape}" if isinstance(depth, np.ndarray) else ""),
        )

        zones = result.get("zones")
        if isinstance(zones, dict):
            check("zones has left/center/right", set(zones) == {"left", "center", "right"})
            ok = all(
                isinstance(v, (int, float)) and 0.0 <= float(v) <= 1.0
                for v in zones.values()
            )
            check("zone values are numbers between 0 and 1", ok, f"got {zones}")
        else:
            check("zones is a dictionary", False, f"got {type(zones).__name__}")

        check(
            "level is clear/caution/danger",
            result.get("level") in LEVELS,
            f"got {result.get('level')!r}",
        )

        message = result.get("message")
        check(
            "message is a short string",
            isinstance(message, str) and 0 < len(message) < 300,
            f"got {type(message).__name__}",
        )

        tone = result.get("tone")
        check("tone is (sample_rate, samples) or None", tone is None or _is_audio(tone))
    else:
        for key in REQUIRED_KEYS:
            check(f"result has key '{key}'", False, "(process_frame did not return a dict)")

    try:
        backend.process_frame(None)
        check("process_frame(None) does not crash", True)
    except Exception as e:
        check("process_frame(None) does not crash", False, f"({type(e).__name__}: {e})")

    try:
        spoken = backend.speak("Test")
        check("speak('Test') is audio or None", spoken is None or _is_audio(spoken))
    except Exception as e:
        check("speak('Test') does not crash", False, f"({type(e).__name__}: {e})")

    print("-" * 60)
    if failures == 0:
        print(f"ALL CHECKS PASSED - {module_name} follows the contract.")
    else:
        print(f"{failures} check(s) FAILED - see above.")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
