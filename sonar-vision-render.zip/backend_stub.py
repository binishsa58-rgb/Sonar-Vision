"""backend_stub.py - a FAKE backend so you can test the app before your
teammates' real backend (sonar_core.py) is ready.

It follows the backend contract exactly:
    process_frame(frame_rgb) -> dict with keys:
        depth_vis : uint8 image (H x W x 3) - a color "depth map" to show
        zones     : {"left": 0..1, "center": 0..1, "right": 0..1}
                    (0.0 = far away, 1.0 = very close)
        level     : "clear" | "caution" | "danger"
        message   : short text like "Obstacle left, close"
        tone      : (sample_rate, samples) or None  (stereo sound to play)
    speak(text, lang="en") -> (sample_rate, samples) or None

How the fake "depth" works (simple on purpose):
    It measures how BRIGHT each part of the camera image is.
    Dark area  -> treated as "something is very close" (try covering the
                  camera with your hand: the app should say DANGER).
    Bright area -> treated as "open space" (point at a lit wall: CLEAR).
    Your teammates' real depth model will replace this logic later.
"""

import numpy as np

SAMPLE_RATE = 22050  # how many sound samples per second (CD quality is 44100)


# --------------------------------------------------------------------------
# Sound helpers
# --------------------------------------------------------------------------
def _beep(freq_hz, duration_s, volume=0.25):
    """Make one short beep as a numpy array (mono)."""
    t = np.linspace(0.0, duration_s, int(SAMPLE_RATE * duration_s), endpoint=False)
    wave = np.sin(2.0 * np.pi * freq_hz * t)  # a pure sine tone
    # Fade the start and end so the beep doesn't "click".
    fade = int(SAMPLE_RATE * 0.01)
    if len(wave) > 2 * fade:
        wave[:fade] *= np.linspace(0.0, 1.0, fade)
        wave[-fade:] *= np.linspace(1.0, 0.0, fade)
    return (wave * volume).astype(np.float32)


def _to_stereo(mono, left_gain=1.0, right_gain=1.0):
    """Copy a mono sound into two channels so it feels left/right panned."""
    n = len(mono)
    stereo = np.zeros((n, 2), dtype=np.float32)
    stereo[:, 0] = mono * left_gain   # channel 0 = LEFT ear
    stereo[:, 1] = mono * right_gain  # channel 1 = RIGHT ear
    return stereo


def _gap(seconds):
    """A short silence between beeps."""
    return np.zeros(int(SAMPLE_RATE * seconds), dtype=np.float32)


def _make_tone(level, zone):
    """Turn (level, zone) into a stereo beep pattern. Pan towards the zone."""
    # How much to lean towards the side the obstacle is on.
    pan = {"left": (1.0, 0.25), "center": (0.8, 0.8), "right": (0.25, 1.0)}[zone]

    if level == "danger":
        # Fast urgent beeps, high pitch.
        beep = _beep(880.0, 0.10, volume=0.35)
        mono = np.concatenate([beep, _gap(0.08)] * 5)
        return _to_stereo(mono, *pan)

    if level == "caution":
        # Two slower medium beeps.
        beep = _beep(660.0, 0.15, volume=0.3)
        mono = np.concatenate([beep, _gap(0.15), beep])
        return _to_stereo(mono, *pan)

    # "clear": one soft low blip so the user knows the app is alive.
    return _to_stereo(_beep(440.0, 0.12, volume=0.15), 1.0, 1.0)


# --------------------------------------------------------------------------
# The two functions required by the contract
# --------------------------------------------------------------------------
def process_frame(frame_rgb):
    """Look at one camera image and describe how close things are."""
    # Gradio should always hand us a numpy image, but be gentle if not.
    if frame_rgb is None or not isinstance(frame_rgb, np.ndarray) or frame_rgb.ndim < 2:
        return {
            "depth_vis": np.zeros((240, 320, 3), dtype=np.uint8),
            "zones": {"left": 0.0, "center": 0.0, "right": 0.0},
            "level": "clear",
            "message": "No camera image yet",
            "tone": None,
        }

    # 1) Turn the colour image into grey levels (0 = black, 255 = white).
    gray = frame_rgb.astype(np.float32).mean(axis=2)

    # 2) Shrink for speed: fit the image into ~320 pixels wide.
    h, w = gray.shape
    scale = min(1.0, 320.0 / w)
    if scale < 1.0:
        new_h, new_w = max(1, int(h * scale)), max(1, int(w * scale))
        rows = (np.arange(new_h) / scale).astype(int).clip(0, h - 1)
        cols = (np.arange(new_w) / scale).astype(int).clip(0, w - 1)
        small = gray[np.ix_(rows, cols)]
        vis_h, vis_w = new_h, new_w
    else:
        small, vis_h, vis_w = gray, h, w

    # 3) "Closeness": dark pixels look close (1.0), bright pixels look far (0.0).
    closeness = 1.0 - (small / 255.0)

    # 4) Split into thirds -> left / center / right zones.
    third = vis_w // 3
    zones = {
        "left": float(closeness[:, :third].mean()),
        "center": float(closeness[:, third:2 * third].mean()),
        "right": float(closeness[:, 2 * third:].mean()),
    }
    # Clamp to the 0..1 range the contract promises.
    for key in zones:
        zones[key] = round(min(1.0, max(0.0, zones[key])), 3)

    # 5) Pick a warning level from the closest zone.
    worst_zone = max(zones, key=zones.get)
    worst = zones[worst_zone]
    if worst >= 0.70:
        level = "danger"
    elif worst >= 0.45:
        level = "caution"
    else:
        level = "clear"

    # 6) Build a short spoken-style message.
    if level == "clear":
        message = "All clear"
    else:
        nearness = "very close" if level == "danger" else "close"
        message = f"Obstacle {worst_zone}, {nearness}"

    # 7) Make the fake depth picture: green = far, yellow = mid, red = close.
    v = (closeness * 255.0).astype(np.uint8)          # how close each pixel is
    depth_vis = np.zeros((vis_h, vis_w, 3), dtype=np.uint8)
    depth_vis[:, :, 0] = v                             # red grows when close
    depth_vis[:, :, 1] = 255 - v                       # green shrinks when close
    # (blue stays 0) -> far = green, middle = yellow, very close = red

    tone = _make_tone(level, worst_zone)
    return {
        "depth_vis": depth_vis,
        "zones": zones,
        "level": level,
        "message": message,
        "tone": (SAMPLE_RATE, tone),
    }


def speak(text, lang="en"):
    """Placeholder 'speech': a short friendly chirp.

    The real backend will return REAL spoken audio here. The stub cannot
    make human speech without extra libraries, so it plays a little chirp
    instead. The words themselves are shown on screen in the app.
    """
    if not text:
        return None
    chirps = [_beep(520.0, 0.07, volume=0.2),
              _gap(0.05),
              _beep(700.0, 0.07, volume=0.2),
              _gap(0.05),
              _beep(880.0, 0.09, volume=0.2)]
    return (SAMPLE_RATE, np.concatenate(chirps).astype(np.float32))
