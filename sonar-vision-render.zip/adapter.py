"""adapter.py - wraps the teammates' sonar_live.py so it follows the app contract.

THE CONTRACT (from the project brief - never changed):
    process_frame(frame_rgb) -> {
        "depth_vis": uint8 image H x W x 3,
        "zones": {"left": 0..1, "center": 0..1, "right": 0..1},  # 0 = far, 1 = close
        "level": "clear" | "caution" | "danger",
        "message": short text,
        "tone": (sample_rate, samples) or None,
    }
    speak(text, lang="en") -> (sample_rate, samples) or None

WHAT WE REUSE FROM sonar_live.py (their file - never modified):
    - get_zone, get_risk, zone_has_obstacle, choose_side_to_check, make_warning
      (their object detection and warning-text logic, called exactly as their loop does)
    - create_depth_display (their depth picture with the INFERNO colormap)
    - DETECTION_SIZE, CONFIDENCE, FRAME_WIDTH, FRAME_HEIGHT (their settings)

WHAT CHANGED compared to their main() loop:
    - Their code opens the camera with cv2.VideoCapture and shows windows with
      cv2.imshow in an endless loop. The Gradio webcam replaces all of that:
      we reuse ONLY the per-frame processing part.
    - Their models were loaded inside main(); here they load ONCE at import.
    - Their speak() pipes text to a Kokoro subprocess that only runs on macOS
      (.venv-kokoro/bin/python + the "afplay" command). On this PC we call the
      kokoro package directly and RETURN the audio array instead of playing it.
    - Their speak() also rate-limits messages (SPEECH_GAP / REPEAT_GAP);
      that was for their endless loop - the app now decides how often to call.
    - Their backend has NO sonar tone (voice only), so the stereo tone comes
      from the tested beep generator in backend_stub.py, driven by their level/zone.

DEPTH DIRECTION: Depth Anything V2 predicts RELATIVE INVERSE depth, where a
HIGHER value means CLOSER. We verify this empirically after installing the
model; if the demo ever looks inverted, set INVERT_DEPTH = True.

PERFORMANCE: the object detector runs on every frame (~0.06 s). The depth
model is slow (~2 s on CPU), so it runs in a background thread and the
displayed depth picture / zone numbers refresh about every 2 seconds -
process_frame itself always returns fast, keeping the app in sync with the
camera.
"""

import os
import threading
import time

import cv2
import numpy as np
from PIL import Image

import backend_stub  # our file - used only for its stereo beep generator
import sonar_live    # the teammates' file - read-only, never modified

BASE = os.path.dirname(os.path.abspath(__file__))

INVERT_DEPTH = False      # set True if the demo shows far/near swapped

# --------------------------------------------------------------------------
# Load the models ONCE at import time (not on every frame)
# --------------------------------------------------------------------------
print("[adapter] Loading YOLO object detector (yolov8n.pt)...")
from ultralytics import YOLO  # noqa: E402 (import after the intro print)

detector = YOLO(os.path.join(BASE, "yolov8n.pt"))

print("[adapter] Loading Depth Anything V2 Small (first run downloads it)...")
from transformers import pipeline  # noqa: E402

depth_model = pipeline("depth-estimation", model="depth-anything/Depth-Anything-V2-Small-hf")
print("[adapter] Models ready.")

# Speech model (loaded once, on the first speak() call - not on every frame).
_kokoro = None
KOKORO_SAMPLE_RATE = 24000  # same rate their kokoro_worker.py writes

# Depth runs in a BACKGROUND THREAD so process_frame always returns fast.
# Why: the depth model needs ~2 seconds per run on a normal laptop CPU.
# Their loop ran it inline every 5th frame, which froze the app for ~2 s at
# a time (frames queued up and the screen fell behind the camera - the
# "out of sync" problem). Now process_frame is always fast (YOLO only,
# ~0.2 s) and the depth picture/zone numbers refresh every DEPTH_EVERY_S.
#
# THREAD POLITENESS (measured on the demo laptop, 8 cores): if this thread
# runs the depth model back to back with no pause, it keeps every core busy
# and Gradio's own web loop can no longer answer requests - a click then
# waits 3-7 seconds for a reply even though the analysis takes 0.2 s. So the
# thread (1) only works on frames it has not seen before and (2) rests
# DEPTH_EVERY_S between runs. torch is also capped so one model does not
# grab all the cores.
import torch  # noqa: E402  (the models above already needed it; this is cheap)

torch.set_num_threads(max(1, (os.cpu_count() or 4) // 4))  # 8 cores -> 2 threads

_depth_lock = threading.Lock()
_latest_frame_bgr = None
_cached_depth_vis = None
_cached_zones = None
_frame_seq = 0          # bumped for every NEW camera frame
DEPTH_EVERY_S = 2.0     # rest between depth runs (seconds)


def _depth_refresher():
    """Background loop: refresh the depth picture for new frames only."""
    seen = 0
    while True:
        with _depth_lock:
            frame, seq = _latest_frame_bgr, _frame_seq
        if frame is None or seq == seen:
            time.sleep(0.25)  # nothing new to look at - stay off the CPU
            continue
        seen = seq
        try:
            _run_depth(frame)
        except Exception as e:
            print(f"[adapter] depth refresh failed: {type(e).__name__}: {e}")
        time.sleep(DEPTH_EVERY_S)  # let the web server and voice breathe


threading.Thread(target=_depth_refresher, daemon=True).start()


def _detect_objects(frame_bgr):
    """Run their YOLO detection and build the objects list.

    This is the object-detection part of their main() loop, line for line:
    same detector.predict() call, same zone and risk helpers, same clamping.
    """
    height, width = frame_bgr.shape[:2]
    frame_area = height * width
    objects = []

    results = detector.predict(
        frame_bgr,
        imgsz=sonar_live.DETECTION_SIZE,
        conf=sonar_live.CONFIDENCE,
        verbose=False,
    )

    for result in results:
        for box in result.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
            class_id = int(box.cls[0].item())
            confidence = float(box.conf[0].item())
            name = detector.names[class_id].lower()

            x1 = max(0, min(x1, width - 1))
            x2 = max(0, min(x2, width - 1))
            y1 = max(0, min(y1, height - 1))
            y2 = max(0, min(y2, height - 1))

            box_area = max(0, x2 - x1) * max(0, y2 - y1)
            if box_area == 0:
                continue

            center_x = (x1 + x2) / 2
            zone = sonar_live.get_zone(center_x, width)
            risk, _risk_label = sonar_live.get_risk(box_area, frame_area)

            objects.append({"name": name, "zone": zone, "risk": risk, "area": box_area})

    return objects


def _run_depth(frame_bgr):
    """Run their depth model and convert the result to zones + depth_vis.

    - The model input is the same as their loop: a PIL image in RGB.
    - The zone numbers come from the depth map the same way their
      create_depth_display normalizes it (2nd-98th percentile, clipped 0..1):
      HIGHER model value = CLOSER, so the mean per third is already a
      "closeness" from 0 (far) to 1 (close) - no inversion needed.
    - Their create_depth_display returns a BGR picture (OpenCV convention);
      the app wants RGB, so we convert it here.
    """
    global _cached_depth_vis, _cached_zones

    height, width = frame_bgr.shape[:2]

    rgb_frame = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    depth_result = depth_model(Image.fromarray(rgb_frame))
    depth_map = np.asarray(depth_result["depth"], dtype=np.float32)

    # Same percentile normalization their create_depth_display uses.
    low = float(np.percentile(depth_map, 2))
    high = float(np.percentile(depth_map, 98))
    if high <= low:
        normalized = np.zeros_like(depth_map)
    else:
        normalized = np.clip((depth_map - low) / (high - low), 0.0, 1.0)

    if INVERT_DEPTH:
        normalized = 1.0 - normalized

    # Resize to the frame size (their display does the same) so the picture
    # thirds line up with the camera image thirds.
    norm_resized = cv2.resize(normalized, (width, height), interpolation=cv2.INTER_LINEAR)
    third = width // 3
    _cached_zones = {
        "left": float(norm_resized[:, :third].mean()),
        "center": float(norm_resized[:, third: 2 * third].mean()),
        "right": float(norm_resized[:, 2 * third:].mean()),
    }

    display_bgr = sonar_live.create_depth_display(depth_result["depth"], width, height)
    _cached_depth_vis = cv2.cvtColor(display_bgr, cv2.COLOR_BGR2RGB)


def process_frame(frame_rgb):
    """One camera frame (RGB numpy) -> the contract dictionary."""
    global _latest_frame_bgr, _frame_seq

    safe = {
        "depth_vis": np.zeros((240, 320, 3), dtype=np.uint8),
        "zones": {"left": 0.0, "center": 0.0, "right": 0.0},
        "level": "clear",
        "message": "No camera image yet",
        "tone": None,
    }
    if not isinstance(frame_rgb, np.ndarray) or frame_rgb.ndim < 3:
        return safe

    frame_rgb = np.ascontiguousarray(frame_rgb[:, :, :3])  # drop alpha if present
    if frame_rgb.dtype != np.uint8:
        frame_rgb = np.clip(frame_rgb, 0, 255).astype(np.uint8)

    # Same resize their loop does, then to the BGR their detector expects.
    frame_bgr = cv2.resize(
        frame_rgb,
        (sonar_live.FRAME_WIDTH, sonar_live.FRAME_HEIGHT),
        interpolation=cv2.INTER_LINEAR,
    )
    frame_bgr = cv2.cvtColor(frame_bgr, cv2.COLOR_RGB2BGR)

    # Hand the frame to the background depth thread (it keeps its own copy
    # of the newest frame, so it never works on a half-written array).
    # The counter tells that thread "this picture is new, worth a run".
    with _depth_lock:
        _latest_frame_bgr = frame_bgr.copy()
        _frame_seq += 1

    # Object detection: every frame, exactly like their loop.
    objects = _detect_objects(frame_bgr)

    # Zones/depth picture come from the background thread (a couple of
    # seconds old at most). If the very first depth run is not finished
    # yet, run it once here so the first frame has real numbers.
    if _cached_depth_vis is None:
        _run_depth(frame_bgr)

    zones = {
        key: round(min(1.0, max(0.0, value)), 3)
        for key, value in (_cached_zones or safe["zones"]).items()
    }

    # ---- Level from the zones, per the contract thresholds ----
    worst_zone = max(zones, key=zones.get)
    worst = zones[worst_zone]
    if worst > 0.75:
        level = "danger"
    elif worst >= 0.5:
        level = "caution"
    else:
        level = "clear"

    # ---- Message: their warning text, same call their loop makes ----
    message = ""
    if objects:
        highest = max(objects, key=lambda item: (item["risk"], item["area"]))
        if highest["risk"] >= 1:
            message = sonar_live.make_warning(highest, objects)
            # Their HIGH risk is a danger to us, MEDIUM at least a caution -
            # never show a softer status than their own warning text.
            yolo_level = "danger" if highest["risk"] >= 2 else "caution"
            rank = {"clear": 0, "caution": 1, "danger": 2}
            if rank[yolo_level] > rank[level]:
                level = yolo_level

    if not message:
        if level == "clear":
            message = "All clear"
        else:
            nearness = "very close" if level == "danger" else "close"
            message = f"Obstacle {worst_zone}, {nearness}"

    # ---- Tone: their backend is voice-only, so use the stub's beeps ----
    tone = backend_stub._make_tone(level, worst_zone)

    return {
        "depth_vis": _cached_depth_vis,
        "zones": zones,
        "level": level,
        "message": message,
        "tone": (backend_stub.SAMPLE_RATE, tone),
    }


def speak(text, lang="en"):
    """Text -> (24000, samples), or None when kokoro is not installed.

    Their kokoro_worker.py builds exactly this audio array at 24000 Hz and
    then plays it with afplay (macOS only). We return the array instead so
    the app can play it in the browser. The words also appear as text in
    the app, so returning None never loses information.
    """
    global _kokoro

    text = (text or "").strip()
    if not text:
        return None

    try:
        from kokoro import KPipeline
    except ImportError:
        print(
            "[adapter] kokoro is not installed, so spoken audio is off "
            "(the words still appear as text). To enable it: pip install kokoro"
        )
        return None

    try:
        if _kokoro is None:
            _kokoro = KPipeline(lang_code="a")  # 'a' = American English, like their worker

        chunks = []
        for _, _, audio in _kokoro(text, voice="af_heart"):
            chunks.append(np.asarray(audio, dtype=np.float32))

        if not chunks:
            return None
        return (KOKORO_SAMPLE_RATE, np.concatenate(chunks))
    except Exception as e:
        print(f"[adapter] speech failed: {type(e).__name__}: {e}")
        return None
