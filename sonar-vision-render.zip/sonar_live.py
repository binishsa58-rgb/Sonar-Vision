import os
import sys
import time
import subprocess

import cv2
import numpy as np
from PIL import Image
from ultralytics import YOLO
from transformers import pipeline


# =========================================================
# SONAR VISION CONFIGURATION
# =========================================================

CAMERA_INDEX = 0
FRAME_WIDTH = 640
FRAME_HEIGHT = 480
DETECTION_SIZE = 320
CONFIDENCE = 0.40

MEDIUM_AREA = 0.07
HIGH_AREA = 0.20

# Use the camera image without horizontal mirroring.
MIRROR_CAMERA = False

SPEECH_GAP = 2.5
REPEAT_GAP = 6.0

# Smooth the displayed relative-depth map.
DEPTH_SMOOTHING = 0.70

BASE = os.path.dirname(os.path.abspath(__file__))
KOKORO_PYTHON = os.path.join(
    BASE, ".venv-kokoro", "bin", "python"
)
KOKORO_WORKER = os.path.join(
    BASE, "kokoro_worker.py"
)

voice = None
last_spoken = 0.0
last_signature = ""
last_signature_time = 0.0
smoothed_depth = None


# =========================================================
# VOICE
# =========================================================

def start_voice():
    global voice

    if not os.path.isfile(KOKORO_PYTHON):
        raise FileNotFoundError(
            "Kokoro environment not found: " + KOKORO_PYTHON
        )

    if not os.path.isfile(KOKORO_WORKER):
        raise FileNotFoundError(
            "kokoro_worker.py not found."
        )

    voice = subprocess.Popen(
        [KOKORO_PYTHON, KOKORO_WORKER],
        cwd=BASE,
        stdin=subprocess.PIPE,
        text=True,
        bufsize=1,
    )

    # Allow the speech model to initialize.
    time.sleep(8)

    if voice.poll() is not None:
        raise RuntimeError("Kokoro worker failed to start.")


def speak(message, signature="general", force=False):
    global last_spoken, last_signature, last_signature_time

    now = time.time()

    if voice is None or voice.poll() is not None:
        return

    if not force:
        if now - last_spoken < SPEECH_GAP:
            return

        if (
            signature == last_signature
            and now - last_signature_time < REPEAT_GAP
        ):
            return

    try:
        voice.stdin.write(message.strip() + "\n")
        voice.stdin.flush()

        last_spoken = now
        last_signature = signature
        last_signature_time = now

        print("VOICE:", message)

    except (BrokenPipeError, OSError) as error:
        print("Voice error:", error)


# =========================================================
# OBJECT DETECTION HELPERS
# =========================================================

def get_zone(center_x, width):
    if center_x < width / 3:
        return "LEFT"

    if center_x < 2 * width / 3:
        return "CENTER"

    return "RIGHT"


def get_risk(box_area, frame_area):
    ratio = box_area / max(frame_area, 1)

    if ratio >= HIGH_AREA:
        return 2, "HIGH"

    if ratio >= MEDIUM_AREA:
        return 1, "MEDIUM"

    return 0, "LOW"


def zone_has_obstacle(objects, zone):
    """Return True if a detected object occupies this zone."""
    return any(
        obj["zone"] == zone and obj["risk"] >= 1
        for obj in objects
    )


def choose_side_to_check(objects):
    """
    Suggest which side to CHECK, not a guaranteed safe route.
    Bounding-box detections cannot establish real-world clearance.
    """
    left_blocked = zone_has_obstacle(objects, "LEFT")
    right_blocked = zone_has_obstacle(objects, "RIGHT")

    if left_blocked and right_blocked:
        return (
            "Obstacles detected on both sides. "
            "Stop and wait for assistance."
        )

    if left_blocked:
        return (
            "An obstacle is detected on the left. "
            "Check the right side carefully before moving."
        )

    if right_blocked:
        return (
            "An obstacle is detected on the right. "
            "Check the left side carefully before moving."
        )

    return (
        "Person or obstacle ahead. Stop and check both sides "
        "before deciding where to move."
    )


def make_warning(obj, objects):
    name = obj["name"]
    zone = obj["zone"]
    risk = obj["risk"]

    if zone == "CENTER":
        if name == "person":
            return (
                "Stop. Person detected ahead. "
                + choose_side_to_check(objects)
            )

        if risk == 2:
            return (
                f"Stop. {name} detected ahead. "
                + choose_side_to_check(objects)
            )

        return (
            f"Caution. {name} detected ahead. "
            + choose_side_to_check(objects)
        )

    if zone == "LEFT":
        message = (
            f"{name} detected on your left. "
            "Check the right side carefully before moving."
        )
    else:
        message = (
            f"{name} detected on your right. "
            "Check the left side carefully before moving."
        )

    if risk == 2:
        return "Stop. High estimated visual risk. " + message

    return "Caution. " + message


# =========================================================
# RELATIVE DEPTH DISPLAY
# =========================================================

def create_depth_display(depth_image, width, height):
    """
    Robust percentile normalization reduces extreme-value effects.
    Colors represent relative model output, not metres or feet.
    """
    global smoothed_depth

    depth = np.asarray(depth_image, dtype=np.float32)

    low = float(np.percentile(depth, 2))
    high = float(np.percentile(depth, 98))

    if high <= low:
        normalized = np.zeros_like(depth, dtype=np.float32)
    else:
        normalized = np.clip(
            (depth - low) / (high - low),
            0.0,
            1.0,
        )

    if smoothed_depth is None or smoothed_depth.shape != normalized.shape:
        smoothed_depth = normalized.copy()
    else:
        smoothed_depth = (
            DEPTH_SMOOTHING * smoothed_depth
            + (1.0 - DEPTH_SMOOTHING) * normalized
        )

    gray = (smoothed_depth * 255).astype(np.uint8)

    colored = cv2.applyColorMap(
        gray,
        cv2.COLORMAP_INFERNO,
    )

    colored = cv2.resize(
        colored,
        (width, height),
        interpolation=cv2.INTER_LINEAR,
    )

    cv2.putText(
        colored,
        "RELATIVE DEPTH - NOT REAL DISTANCE",
        (10, 25),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.48,
        (255, 255, 255),
        1,
        cv2.LINE_AA,
    )

    cv2.putText(
        colored,
        "Colors show relative model output only",
        (10, height - 15),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.42,
        (255, 255, 255),
        1,
        cv2.LINE_AA,
    )

    return colored


# =========================================================
# MAIN PROGRAM
# =========================================================

def main():
    global smoothed_depth

    print("Starting Sonar Vision...")

    start_voice()

    print("Loading YOLO object detector...")
    detector = YOLO("yolov8n.pt")

    print("Loading Depth Anything...")
    depth_model = pipeline(
        "depth-estimation",
        model="depth-anything/Depth-Anything-V2-Small-hf",
    )

    camera = cv2.VideoCapture(CAMERA_INDEX)

    if not camera.isOpened():
        raise RuntimeError(
            "Could not open the camera. Check macOS camera permissions."
        )

    camera.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_WIDTH)
    camera.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)

    time.sleep(1)

    speak(
        "Sonar Vision is live. Voice warnings are active. "
        "Please move carefully.",
        signature="startup",
        force=True,
    )

    print("Sonar Vision is live. Press Q to quit.")

    frame_count = 0
    depth_display = None

    try:
        while True:
            ok, original_frame = camera.read()

            if not ok:
                print("Unable to read camera frame.")
                break

            if MIRROR_CAMERA:
                frame = cv2.flip(original_frame, 1)
            else:
                frame = original_frame.copy()

            frame = cv2.resize(
                frame,
                (FRAME_WIDTH, FRAME_HEIGHT),
            )

            height, width = frame.shape[:2]
            frame_area = height * width
            annotated = frame.copy()
            objects = []

            # ---------------- Object detection ----------------

            results = detector.predict(
                frame,
                imgsz=DETECTION_SIZE,
                conf=CONFIDENCE,
                verbose=False,
            )

            for result in results:
                for box in result.boxes:
                    x1, y1, x2, y2 = map(
                        int,
                        box.xyxy[0].tolist(),
                    )

                    class_id = int(box.cls[0].item())
                    confidence = float(box.conf[0].item())
                    name = detector.names[class_id].lower()

                    x1 = max(0, min(x1, width - 1))
                    x2 = max(0, min(x2, width - 1))
                    y1 = max(0, min(y1, height - 1))
                    y2 = max(0, min(y2, height - 1))

                    box_area = (
                        max(0, x2 - x1)
                        * max(0, y2 - y1)
                    )

                    if box_area == 0:
                        continue

                    center_x = (x1 + x2) / 2
                    zone = get_zone(center_x, width)

                    risk, risk_label = get_risk(
                        box_area,
                        frame_area,
                    )

                    obj = {
                        "name": name,
                        "zone": zone,
                        "risk": risk,
                        "area": box_area,
                    }

                    objects.append(obj)

                    if risk == 2:
                        color = (0, 0, 255)
                    elif risk == 1:
                        color = (0, 165, 255)
                    else:
                        color = (0, 200, 0)

                    cv2.rectangle(
                        annotated,
                        (x1, y1),
                        (x2, y2),
                        color,
                        2,
                    )

                    label = (
                        f"{name} {confidence:.2f} "
                        f"{zone} {risk_label}"
                    )

                    cv2.putText(
                        annotated,
                        label,
                        (x1, max(20, y1 - 8)),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.45,
                        color,
                        2,
                    )

            # ---------------- Zone markers ----------------

            third = width // 3

            cv2.line(
                annotated,
                (third, 0),
                (third, height),
                (255, 255, 0),
                1,
            )

            cv2.line(
                annotated,
                (2 * third, 0),
                (2 * third, height),
                (255, 255, 0),
                1,
            )

            for label, x in (
                ("LEFT", 10),
                ("CENTER", third + 10),
                ("RIGHT", 2 * third + 10),
            ):
                cv2.putText(
                    annotated,
                    label,
                    (x, 25),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (255, 255, 0),
                    2,
                )

            # ---------------- Voice guidance ----------------

            if objects:
                highest = max(
                    objects,
                    key=lambda item: (
                        item["risk"],
                        item["area"],
                    ),
                )

                if highest["risk"] >= 1:
                    message = make_warning(highest, objects)

                    signature = (
                        f'{highest["risk"]}:'
                        f'{highest["name"]}:'
                        f'{highest["zone"]}:'
                        f'{zone_has_obstacle(objects, "LEFT")}:'
                        f'{zone_has_obstacle(objects, "RIGHT")}'
                    )

                    speak(message, signature)

            # ---------------- Relative depth ----------------

            frame_count += 1

            if frame_count % 5 == 0 or depth_display is None:
                rgb_frame = cv2.cvtColor(
                    frame,
                    cv2.COLOR_BGR2RGB,
                )

                depth_result = depth_model(
                    Image.fromarray(rgb_frame)
                )

                depth_display = create_depth_display(
                    depth_result["depth"],
                    FRAME_WIDTH,
                    FRAME_HEIGHT,
                )

            cv2.imshow(
                "Sonar Vision - Object Detection",
                annotated,
            )

            cv2.imshow(
                "Sonar Vision - Relative Depth",
                depth_display,
            )

            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

    finally:
        camera.release()
        cv2.destroyAllWindows()

        if voice is not None:
            try:
                voice.stdin.close()
                voice.terminate()
                voice.wait(timeout=3)
            except Exception:
                try:
                    voice.kill()
                except Exception:
                    pass

        print("Sonar Vision stopped.")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"SONAR VISION ERROR: {error}")
        sys.exit(1)