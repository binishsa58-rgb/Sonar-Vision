"""tinyfish_smoke_test.py - makes ONE real TinyFish search request and stops.

Run:  .venv\\Scripts\\python tinyfish_smoke_test.py
      .venv\\Scripts\\python tinyfish_smoke_test.py "any other search phrase"

It prints ONLY: whether TINYFISH_API_KEY is present, whether the call
succeeded, how many results came back, and each result's title and URL.
The key value is never printed, and no web agent is run (that would spend
more credit).
"""

import os
import sys

from dotenv import load_dotenv

load_dotenv()  # reads .env next to this file

DEFAULT_QUERY = "John Rylands Library Manchester official website"


def main():
    query = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_QUERY
    key = os.getenv("TINYFISH_API_KEY", "").strip()

    print("TINYFISH_API_KEY present in environment:", bool(key))
    if not key:
        print("RESULT: SKIPPED - no key in .env, so nothing was sent.")
        return 1

    try:
        from tinyfish import TinyFish
    except Exception as e:
        print(f"RESULT: FAILED - the tinyfish package did not import "
              f"({type(e).__name__}: {e})")
        return 1

    print("call: client.search.query  ->  GET https://api.search.tinyfish.ai")
    print("query:", query)
    try:
        response = TinyFish().search.query(query=query)
    except Exception as e:
        # Scrub the key in case an error message ever echoes it back.
        print("RESULT: FAILED -", f"{type(e).__name__}: {e}".replace(key, "***"))
        return 1

    results = list(getattr(response, "results", None) or [])
    print(f"RESULT: SUCCESS - {len(results)} result(s) returned "
          f"(total_results={getattr(response, 'total_results', 'not reported')})")
    for i, item in enumerate(results[:5], 1):
        title = str(getattr(item, "title", "") or "")[:70]
        url = str(getattr(item, "url", "") or "")
        print(f"  {i}. {title} -> {url}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
