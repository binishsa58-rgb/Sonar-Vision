"""tinyfish_scout.py - the "scout" pipeline for "Ask about this place".

Given a place name (and optionally its official web page), this generator
walks through stages and yields one dict per step so a user interface can
show progress live:

    {"stage": "search" | "fetch" | "agent" | "cache" | "done" | "error",
     "message": "...plain English...",
     "data": {five fields},        <- only on "done" and "cache"
     "source": "Fetch" | "Web Agent" | "Fetch" (saved),   <- only on "done"/"cache"
     "cached_at": "...date..."}    <- only on "done"/"cache"

The five fields: hours, step_free_entrance, lift, tactile_path, help_contact.
Anything the page does not say is exactly "not stated".

Safety rules:
    - The API key is read ONLY from the environment (TINYFISH_API_KEY,
      loaded from .env). It is NEVER printed - error messages are scrubbed.
    - Every network call is inside try/except. On ANY failure we fall back
      to the last saved answer in cache/<place-slug>.json.
    - The web agent is optional: it only runs when the cheap keyword reader
      found fewer than 3 of the 5 fields, and it never waits past 90 s.

Test from the terminal (this can spend a little TinyFish credit):
    python tinyfish_scout.py "Place name" https://official-page-url
    python tinyfish_scout.py "Place name"          # searches for the page
"""

import json
import os
import re
import sys
import time
import unicodedata
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()  # reads .env for TINYFISH_API_KEY

CACHE_DIR = Path(__file__).parent / "cache"
AGENT_TIME_LIMIT_S = 90  # never wait longer than this for the web agent

# Words that suggest a sentence contains each fact we want.
FIELD_KEYWORDS = {
    "hours": [
        "opening hours", "opening times", "timings", "open from", "open daily",
        "open monday", "open tuesday", "open wednesday", "open thursday",
        "open friday", "open saturday", "open sunday", "closed on",
    ],
    "step_free_entrance": [
        "step free", "step-free", "wheelchair", "ramp", "level access",
        "accessible entrance",
    ],
    "lift": ["lift", "elevator"],
    "tactile_path": ["tactile", "braille"],
    "help_contact": [
        "helpline", "help desk", "helpdesk", "contact us", "assistance",
        "phone", "email",
    ],
}

FIELD_LABELS = {
    "hours": "Opening hours",
    "step_free_entrance": "Step-free entrance",
    "lift": "Lift or ramp",
    "tactile_path": "Tactile path",
    "help_contact": "For help, contact",
}

# Sent to the web agent so it returns exactly the five fields as strings.
OUTPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "hours": {"type": "string"},
        "step_free_entrance": {"type": "string"},
        "lift": {"type": "string"},
        "tactile_path": {"type": "string"},
        "help_contact": {"type": "string"},
    },
    "required": [],
}


# --------------------------------------------------------------------------
# Cache helpers
# --------------------------------------------------------------------------
def _slug(place):
    """Turn a place name into a safe file name: 'National Museum' -> 'national-museum'."""
    text = unicodedata.normalize("NFKD", place)
    text = re.sub(r"[^a-zA-Z0-9]+", "-", text).strip("-").lower()
    return (text[:60] or "unknown") + ".json"


def _read_cache(place):
    """Return the saved dict for this place, or None if there is none."""
    path = CACHE_DIR / _slug(place)
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            saved = json.load(f)
        if isinstance(saved, dict) and isinstance(saved.get("data"), dict):
            return saved
    except (OSError, ValueError) as e:
        print(f"[scout] Could not read cache {path.name}: {e}")
    return None


def _write_cache(place, data, source):
    """Save a successful result with the date, so we can use it if offline."""
    saved = {
        "place": place,
        "data": data,
        "source": source,
        "cached_at": datetime.now().isoformat(timespec="seconds"),
    }
    try:
        CACHE_DIR.mkdir(exist_ok=True)
        with open(CACHE_DIR / _slug(place), "w", encoding="utf-8") as f:
            json.dump(saved, f, ensure_ascii=False, indent=2)
    except OSError as e:
        print(f"[scout] Could not save cache: {e}")  # saving is optional
    return saved


def _safe_error_text(error, secret):
    """Make an error message safe to show: hide the API key if it ever appears."""
    text = f"{type(error).__name__}: {error}"
    return text.replace(secret, "***") if secret else text


# --------------------------------------------------------------------------
# The simple keyword reader
# --------------------------------------------------------------------------
def _clean_markdown(text):
    """Turn markdown into plain-ish text: [label](url) -> label, strip #*_`."""
    text = re.sub(r"!?\[([^\]]*)\]\([^)]*\)", r"\1", text or "")
    return re.sub(r"[#*_`>]+", " ", text)


def _sentences(text):
    """Split page text into readable sentences (markdown lists become lines)."""
    chunks = re.split(r"(?<=[.!?])\s+|\n+", _clean_markdown(text))
    return [c.strip() for c in chunks if len(c.strip()) >= 20]  # drop tiny fragments


def _extract_fields(page_text):
    """Find the first sentence per field that mentions a related word.

    Returns the five-field dict; anything not found is exactly "not stated".
    """
    sentences = _sentences(page_text)
    lower = [s.lower() for s in sentences]
    data = {}
    for field, keywords in FIELD_KEYWORDS.items():
        found = "not stated"
        for i, sentence in enumerate(lower):
            if any(word in sentence for word in keywords):
                found = sentences[i][:220]  # keep it speakable
                break
        data[field] = found
    return data


def _count_found(data):
    return sum(1 for v in (data or {}).values() if v and v != "not stated")


# --------------------------------------------------------------------------
# The scout generator
# --------------------------------------------------------------------------
def scout_place(place, official_url=None, use_agent=True):
    """Yield progress dicts for looking up `place`, ending with data+source."""
    place = (place or "").strip()
    if not place:
        yield {"stage": "error", "message": "Please give a place name."}
        return

    secret = os.getenv("TINYFISH_API_KEY", "").strip()
    try:
        # ---- No key? Go straight to the cache. -------------------------
        if not secret:
            yield {"stage": "cache", "message": "No TINYFISH_API_KEY in .env - using the saved answer only."}
            cached = _read_cache(place)
            if cached:
                yield {"stage": "done", "message": "Loaded the saved answer.",
                       "data": cached["data"], "source": cached.get("source", "Cache"),
                       "cached_at": cached.get("cached_at", "unknown date")}
            else:
                yield {"stage": "error", "message": "No API key and no saved answer for this place. "
                                                    "Paste your key into .env and try again."}
            return

        from tinyfish import TinyFish, StreamingUrlEvent, ProgressEvent, CompleteEvent
        client = TinyFish()  # reads TINYFISH_API_KEY from the environment

        # ---- Stage 1: find the official page ---------------------------
        if official_url:
            url = official_url
            yield {"stage": "search", "message": f"Using the page you gave: {url}"}
        else:
            yield {"stage": "search", "message": f"Searching for {place}'s official website..."}
            search_resp = client.search.query(query=f"{place} official website accessibility information")
            results = list(getattr(search_resp, "results", None) or [])
            top = results[0] if results else None
            url = getattr(top, "url", None) if top else None
            title = (getattr(top, "title", "") or "")[:80]
            if not url:
                raise RuntimeError("the search found no website for this place")
            yield {"stage": "search", "message": f"Official page: {title} - {url}"}

        # ---- Stage 2: fetch the page and read it with keywords ---------
        yield {"stage": "fetch", "message": "Reading the page as text..."}
        fetch_resp = client.fetch.get_contents(urls=[url], format="markdown")
        page_text = ""
        fetch_results = list(getattr(fetch_resp, "results", None) or [])
        if fetch_results:
            page_text = getattr(fetch_results[0], "text", "") or ""
        for err in (getattr(fetch_resp, "errors", None) or []):
            print(f"[scout] fetch error for {getattr(err, 'url', '?')}: {getattr(err, 'error', err)}")

        data = _extract_fields(page_text)
        found = _count_found(data)
        source = "Fetch"
        yield {"stage": "fetch", "message": f"The keyword reader found {found} of 5 fields on the page."}

        # ---- Stage 3: the web agent (only if the page text was thin) ---
        if use_agent and found < 3:
            yield {"stage": "agent",
                   "message": "The page text was thin - sending a web agent to read it properly "
                              "(this can take 30-60 seconds and costs a little credit)..."}
            goal = (
                f"You are on the official website of '{place}'. Find exactly these five "
                "accessibility facts: hours (opening hours), step_free_entrance, "
                "lift (or ramp access), tactile_path (tactile paving or braille guidance), "
                "help_contact (who to call or email for assistance). "
                "Use exactly 'not stated' if the page does not say. Do not guess."
            )
            agent_result = None
            started = time.time()
            with client.agent.stream(url=url, goal=goal, output_schema=OUTPUT_SCHEMA) as stream:
                for event in stream:
                    # Stop waiting once 90 seconds have passed. We check on
                    # every event, so we stop as soon as the next one arrives.
                    if time.time() - started > AGENT_TIME_LIMIT_S:
                        raise TimeoutError(f"the web agent took longer than {AGENT_TIME_LIMIT_S} seconds")
                    if isinstance(event, StreamingUrlEvent):
                        yield {"stage": "agent", "message": f"Watch it live: {event.streaming_url}"}
                    elif isinstance(event, ProgressEvent):
                        yield {"stage": "agent", "message": f"Agent: {event.purpose}"}
                    elif isinstance(event, CompleteEvent):
                        status = str(getattr(event, "status", "") or "")
                        if status and status.upper() not in ("COMPLETE", "COMPLETED", "SUCCESS"):
                            yield {"stage": "agent", "message": f"Agent finished with status: {status}"}
                        agent_result = getattr(event, "result_json", None)

            if isinstance(agent_result, dict):
                for key in OUTPUT_SCHEMA["properties"]:
                    value = agent_result.get(key)
                    if value:
                        data[key] = str(value).strip()[:220]
                source = "Web Agent"
                yield {"stage": "agent", "message": f"The agent finished - now {_count_found(data)} of 5 fields found."}
            else:
                yield {"stage": "agent", "message": "The agent did not return usable facts - keeping what the page said."}
        elif use_agent:
            yield {"stage": "agent", "message": "Skipping the agent - the page already answered enough fields."}

        # ---- Done: save and return -------------------------------------
        saved = _write_cache(place, data, source)
        yield {"stage": "done", "message": f"Done - {_count_found(data)} of 5 fields found.",
               "data": data, "source": source, "cached_at": saved["cached_at"]}

    except Exception as e:
        # ---- ANY failure: fall back to the cache ------------------------
        reason = _safe_error_text(e, secret)
        print(f"[scout] Lookup failed: {reason}")
        cached = _read_cache(place)
        if cached:
            yield {"stage": "cache",
                   "message": f"Live lookup failed ({reason}) - using the answer saved on {cached.get('cached_at', 'an earlier date')}.",
                   "data": cached["data"], "source": cached.get("source", "Cache"),
                   "cached_at": cached.get("cached_at", "unknown date")}
        else:
            yield {"stage": "error", "message": f"Lookup failed and nothing is saved yet. ({reason})"}


# --------------------------------------------------------------------------
# Turn the data into 3-4 short sentences to speak aloud
# --------------------------------------------------------------------------
def to_briefing(place, data, source):
    data = data or {}
    facts = [
        f"{label}: {data[key]}".rstrip(".")  # no doubled full stops when spoken
        for key, label in FIELD_LABELS.items()
        if data.get(key) and data[key] != "not stated"
    ]
    first = f"Here is the accessibility briefing for {place}."
    second = ("I found that " + "; ".join(facts) + ".") if facts \
        else "The website did not state any accessibility details."
    third = f"This came from {source} reading the venue's website, and it may be out of date."
    fourth = "Please confirm before you travel."
    return " ".join([first, second, third, fourth])


# --------------------------------------------------------------------------
# Small test: python tinyfish_scout.py "Place name" [https://official-url]
# --------------------------------------------------------------------------
if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        print('Usage: python tinyfish_scout.py "Place name" [https://official-page-url]')
        raise SystemExit(1)

    final = None
    for update in scout_place(args[0], official_url=(args[1] if len(args) > 1 else None)):
        print(f"[{update['stage'].upper():5}] {update['message']}")
        if "data" in update:
            final = update
            print("        source:", final["source"], "| saved:", final.get("cached_at"))
            for key, value in final["data"].items():
                print(f"        {key}: {value}")
    if final:
        print("\nSpoken briefing:\n" + to_briefing(args[0], final["data"], final.get("source", "")))
