import os
import sys
import tempfile
import subprocess

import numpy as np
import soundfile as sf
from kokoro import KPipeline


def main():
    print(
        "Loading Kokoro voice...",
        file=sys.stderr,
        flush=True,
    )

    pipeline = KPipeline(lang_code="a")

    print(
        "Kokoro ready.",
        file=sys.stderr,
        flush=True,
    )

    for line in sys.stdin:
        message = line.strip()

        if not message:
            continue

        audio_path = None

        try:
            chunks = []

            for _, _, audio in pipeline(
                message,
                voice="af_heart",
            ):
                chunks.append(audio)

            if not chunks:
                continue

            audio = np.concatenate(chunks)

            fd, audio_path = tempfile.mkstemp(
                prefix="sonar_voice_",
                suffix=".wav",
            )
            os.close(fd)

            sf.write(audio_path, audio, 24000)

            subprocess.run(
                ["afplay", audio_path],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

        except Exception as error:
            print(
                f"Kokoro error: {error}",
                file=sys.stderr,
                flush=True,
            )

        finally:
            if audio_path and os.path.exists(audio_path):
                try:
                    os.remove(audio_path)
                except OSError:
                    pass


if __name__ == "__main__":
    main()