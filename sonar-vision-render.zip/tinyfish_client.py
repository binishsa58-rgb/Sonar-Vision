"""tinyfish_client.py - the "Ask about this place" feature.

Given a venue name (like "Manchester Central Library"), it:
    1. Uses the TinyFish Search API to find the venue's OFFICIAL website.
    2. Uses a TinyFish web agent to read that site and pull out the
       accessibility facts (opening hours, step-free entrance, lift,
       tactile path, help contact).
    3. Returns a short briefing for the screen AND a plain-text version
       for the app to speak.

Safety rules this file follows:
    - The API key is read ONLY from the environment variable
      TINYFISH_API_KEY (loaded from .env with python-dotenv).
      It is never printed, never hard-coded, never written to disk.
    - EVERY network call is wrapped in try/except. If the network fails,
      we fall back to the last saved answer in the cache/ folder.
"""

import json
import os
import re
import unicodedata
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()  # reads the .env file next to app.py

CACHE_DIR = Path(__file__).parent / "cache"

# Tell the TinyFish agent exactly which facts we want back.
ACCESSIBILITY_SCHEMA = {
    "type": "object",
    "properties": {
        "opening_hours": {"type": "string"},
        "step_free_entrance": {"type": "string"},
        "lift_or_ramp": {"type": "string"},
        "tactile_path": {"type": "string"},
        "help_contact": {"type": "string"},
        "notes": {"type": "string"},
    },
    "required": [],
}


# --------------------------------------------------------------------------
# Cache helpers (saved answers in the cache/ folder)
# --------------------------------------------------------------------------
def _cache_path(venue_name):
    """Turn a venue name into a safe file name, e.g. 'venue-central-library.json'."""
    text = unicodedata.normalize("NFKD", venue_name)
    text = re.sub(r"[^a-zA-Z0-9]+", "-", text).strip("-").lower()
    text = text[:60] or "unknown"
    return CACHE_DIR / f"venue-{text}.json"


def _read_cache(venue_name):
    """Return the cached result dict for this venue, or None if there is none."""
    path = _cache_path(venue_name)
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError) as e:
        # Corrupted cache file - ignore it and act as if it does not exist.
        print(f"[cache] Could not read {path.name}: {e}")
        return None


def _write_cache(venue_name, data):
    """Save a successful result so we can use it later if the network dies."""
    try:
        CACHE_DIR.mkdir(exist_ok=True)
        with open(_cache_path(venue_name), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError as e:
        # Saving is optional - never crash the app because of it.
        print(f"[cache] Could not save result: {e}")


# --------------------------------------------------------------------------
# Small helpers for reading TinyFish answers safely
# --------------------------------------------------------------------------
def _get_field(obj, names):
    """Get the first attribute/key in `names` that exists on `obj`.

    The TinyFish SDK may return objects OR plain dicts depending on the
    endpoint, so we try both styles. This keeps us safe if the SDK changes.
    """
    for name in names:
        value = getattr(obj, name, None)
        if value is not None:
            return value
    if isinstance(obj, dict):
        for name in names:
            if obj.get(name) is not None:
                return obj[name]
    return None


def _extract_first_url(search_response):
    """Pull the first normal web link out of a search response."""
    items = _get_field(search_response, ["results", "organic", "items", "data"])
    if items is None and isinstance(search_response, list):
        items = search_response
    if not items:
        return None
    for item in items:
        if isinstance(item, str) and item.startswith("http"):
            return item
        url = _get_field(item, ["url", "link", "href"])
        if isinstance(url, str) and url.startswith("http"):
            return url
    return None


def _extract_agent_result(response):
    """Get the structured dict the agent produced (result_json and friends)."""
    data = _get_field(response, ["result_json", "result", "data", "output"])
    if data is None:
        return None
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except ValueError:
            return {"notes": data}  # agent replied with plain text - still useful
    return data if isinstance(data, dict) else None


def _safe_error_text(error, secret):
    """Make an error message safe to show: hide the API key if it appears."""
    text = f"{type(error).__name__}: {error}"
    if secret:
        text = text.replace(secret, "***")
    return text


# --------------------------------------------------------------------------
# The main function the app calls
# --------------------------------------------------------------------------
def ask_about_place(venue_name):
    """Return a dict: {ok, briefing, speech_text, source_url, from_cache, error}."""
    venue_name = (venue_name or "").strip()
    nothing = {
        "ok": False, "briefing": "", "speech_text": "",
        "source_url": None, "from_cache": False, "error": "",
    }

    if not venue_name:
        nothing["error"] = "Please type a place name first."
        return nothing

    secret = get_api_key()

    # ---- Try the live network path -------------------------------------
    try:
        if not secret:
            raise RuntimeError(
                "No TINYFISH_API_KEY found. Open the .env file and paste your "
                "key after 'TINYFISH_API_KEY=', then restart the app."
            )

        from tinyfish import TinyFish  # imported here so the app runs even if the SDK is missing
        client = TinyFish()  # reads TINYFISH_API_KEY from the environment itself

        # Step 1: find the official website.
        search = client.search.query(f"{venue_name} official website")
        url = _extract_first_url(search)
        if not url:
            raise RuntimeError("Search found no website for this place name.")

        # Step 2: send an agent to read that website for us.
        goal = (
            f"You are on the official website of '{venue_name}'. Find the "
            "accessibility information: opening hours, step-free entrance, "
            "lift or ramp access, tactile paving / guidance path, and a "
            "contact for assistance. Keep every answer under 15 words. "
            "Write 'Not stated' for anything the page does not say."
        )
        agent_response = client.agent.run(goal=goal, url=url, output_schema=ACCESSIBILITY_SCHEMA)
        facts = _extract_agent_result(agent_response) or {}

        # Anything the agent could not find becomes "Not stated".
        facts = {key: str(facts.get(key) or "Not stated") for key in ACCESSIBILITY_SCHEMA["properties"]}

        # Build the on-screen briefing (markdown) and the spoken version.
        lines = [
            f"**Accessibility briefing - {venue_name}**",
            f"Source: {url}",
            "",
            f"- **Opening hours:** {facts['opening_hours']}",
            f"- **Step-free entrance:** {facts['step_free_entrance']}",
            f"- **Lift or ramp:** {facts['lift_or_ramp']}",
            f"- **Tactile path:** {facts['tactile_path']}",
            f"- **Help contact:** {facts['help_contact']}",
        ]
        if facts["notes"] != "Not stated":
            lines.append(f"- **Notes:** {facts['notes']}")

        speech_text = (
            f"Briefing for {venue_name}. Opening hours: {facts['opening_hours']}. "
            f"Step-free entrance: {facts['step_free_entrance']}. "
            f"Lift or ramp: {facts['lift_or_ramp']}. "
            f"Tactile path: {facts['tactile_path']}. "
            f"For help, contact: {facts['help_contact']}."
        )

        result = {
            "ok": True, "briefing": "\n".join(lines), "speech_text": speech_text,
            "source_url": url, "from_cache": False, "error": "",
            "venue": venue_name,
            "cached_at": datetime.now().isoformat(timespec="seconds"),
        }
        _write_cache(venue_name, result)
        return result

    # ---- Network failed: fall back to the cache ------------------------
    except Exception as e:
        reason = _safe_error_text(e, secret)
        print(f"[tinyfish] Live lookup failed: {reason}")

        cached = _read_cache(venue_name)
        if cached:
            cached = dict(cached)
            cached["from_cache"] = True
            cached["error"] = "Live lookup failed - showing the last saved answer."
            return cached

        nothing["error"] = (
            f"Could not fetch this place, and there is no saved answer yet. "
            f"Details: {reason}"
        )
        return nothing


def get_api_key():
    """Read the API key from the environment. NEVER print or log this value."""
    return os.getenv("TINYFISH_API_KEY", "").strip()
