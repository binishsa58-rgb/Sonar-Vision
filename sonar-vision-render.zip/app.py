"""app.py - Sonar Vision (Gradio front end).

Run it with:  .venv\\Scripts\\python app.py
Then open:    http://127.0.0.1:7860  (the browser should open by itself)

Tab 1 "Live sonar": the webcam sends a frame to the backend twice a second.
     The backend returns a depth picture, how close things are on the
     left/centre/right, a warning level, a short message, and a stereo
     tone. Everything the app "says" is also written to a text log for
     screen readers (and for the judges).
Tab 2 "Demo / Prototype": the built-in cat photo and clip, always usable.
Tab 3 "Ask about this place (TinyFish)": spoken accessibility briefing.
Tab 4 "About": what we built vs what we used, and the limits.
"""

import atexit
import concurrent.futures
import os
import subprocess
import threading
import time
from collections import deque
from pathlib import Path

import gradio as gr
from dotenv import load_dotenv

try:
    import cv2  # used by the direct laptop camera mode
except ImportError:
    cv2 = None

# --------------------------------------------------------------------------
# 1) Choose the backend (this is the switch in .env)
# --------------------------------------------------------------------------
load_dotenv()  # reads .env -> USE_REAL_BACKEND (and TINYFISH_API_KEY later)

if os.getenv("USE_REAL_BACKEND", "0") == "1":
    try:
        import adapter as backend  # wraps the teammates' sonar_live.py (real backend)
    except Exception as e:
        # Plain-English explanation instead of a scary traceback.
        raise SystemExit(
            "USE_REAL_BACKEND is set to 1 in .env, but adapter.py could not be loaded.\n"
            f"Reason: {type(e).__name__}: {e}\n"
            "Fix: install the real backend libraries (pip install ultralytics transformers), "
            "keep sonar_live.py, yolov8n.pt and adapter.py next to app.py, or set "
            "USE_REAL_BACKEND=0 to run with the fake backend for now."
        )
else:
    import backend_stub as backend  # the fake backend, safe for testing

print(f"[backend] loaded module: {backend.__name__}"
      + (" (REAL backend - teammates' code via adapter)" if backend.__name__ == "adapter" else " (FAKE backend for testing)"))

# --------------------------------------------------------------------------
# 1b) The built-in demo files (paths relative to THIS file, so the app works
#     however it is started - from the project folder, from a terminal in
#     another folder, or from a shared link)
# --------------------------------------------------------------------------
PROJECT_DIR = Path(__file__).resolve().parent
DEMO_PHOTO = PROJECT_DIR / "test_photo.jpg"   # the cat prototype photo
DEMO_CLIP = PROJECT_DIR / "demo_walk.mp4"     # the prerecorded walk-up clip


def _asset_warning():
    """Text for the Demo panel + the terminal log. Says nothing scary when the
    files are there; names exactly the missing ones when they are not.
    It never deletes or replaces a file."""
    missing = [p.name for p in (DEMO_PHOTO, DEMO_CLIP) if not p.is_file()]
    if missing:
        print(f"[demo] WARNING - missing built-in demo file(s): {', '.join(missing)}")
        return ("**Warning:** this app cannot find " + " and ".join(f"`{m}`" for m in missing)
                + f" in the project folder `{PROJECT_DIR}`. Put the file(s) back there and "
                "restart. The panel stays - nothing else was changed because of this.")
    return "Both built-in demo files are present: `test_photo.jpg` and `demo_walk.mp4`."


# --------------------------------------------------------------------------
# 2) The alert log: a text copy of everything the app says (max 10 lines)
# --------------------------------------------------------------------------
alert_log = deque(maxlen=10)  # old entries drop off automatically
last_logged_message = ""      # so we don't repeat the same line every 0.5 s

# Tone bookkeeping: the tone must NOT restart on every frame (it would
# sound chopped up or silent). We play a new tone only when the situation
# CHANGES, or every 2 seconds while a warning is active (so danger keeps
# beeping). "clear" plays one soft blip only when we enter it.
_last_tone_key = None   # (level, zone) the last tone was for
_last_tone_time = 0.0   # when we last sent a tone to the player
TONE_REPEAT_S = 2.0     # replay warning tones at most every 2 seconds


def _append_log(text):
    """Add one line to the log and return the whole log as one string."""
    alert_log.append(f"[{time.strftime('%H:%M:%S')}] {text}")
    return "\n".join(alert_log)  # oldest first, newest at the bottom


# --------------------------------------------------------------------------
# 2a) Camera diagnostics: ask Windows what devices it really sees
# --------------------------------------------------------------------------
# Rule for every message below: report what was actually measured, never a
# guess about hardware. A failed cv2.VideoCapture() only proves that THIS
# Python process could not get a frame - it does not prove a camera is
# missing, broken, or switched off in firmware.
def windows_camera_state():
    """What Windows' own device manager says about camera devices - or None.

    Returns lines like "Unknown | HP HD Camera | CM_PROB_PHANTOM" for every
    camera node Windows knows about, including ones that are NOT plugged in /
    NOT enumerated right now. That is the only check that can tell "no camera
    in this machine at the moment" apart from "a camera exists but this app
    could not use it". Needs PowerShell; returns None if the check can't run,
    and then we say nothing about hardware.
    """
    if os.name != "nt":
        return None
    script = (
        "$ErrorActionPreference='SilentlyContinue';"
        "Get-PnpDevice | "
        "Where-Object { $_.Class -eq 'Camera' -or $_.FriendlyName -match 'Camera' } | "
        "ForEach-Object { '{0} | {1} | {2}' -f $_.Status, $_.FriendlyName, $_.Problem }"
    )
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-Command", script],
            capture_output=True, text=True, timeout=15,
        )
    except Exception:
        return None
    if out.returncode != 0:
        return None
    lines = [ln.strip() for ln in out.stdout.splitlines() if ln.strip()]
    return lines


def windows_camera_devices():
    """Camera device names Windows reports as present right now, or None.

    None means the check could not run (not Windows, no PowerShell, or it
    timed out) - callers must then say nothing about hardware at all.
    """
    if os.name != "nt":
        return None
    script = (
        "$ErrorActionPreference='SilentlyContinue';"
        "Get-PnpDevice -PresentOnly | "
        "Where-Object { $_.Class -eq 'Camera' -or $_.Class -eq 'Image' } | "
        "ForEach-Object { $_.FriendlyName }"
    )
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-Command", script],
            capture_output=True, text=True, timeout=10,
        )
    except Exception:
        return None
    if out.returncode != 0:
        return None
    return [name.strip() for name in out.stdout.splitlines() if name.strip()]


def _camera_fault_line():
    """One honest sentence built from Windows' own camera device list.

    It is about the computer running app.py - never about a visitor's laptop.
    """
    state = windows_camera_state()
    if state is None:
        return ("The Windows device check could not run here, so this says nothing "
                "about anyone's hardware.")
    present = [ln for ln in state if ln.split(" | ")[0].strip() == "OK"]
    broken = [ln for ln in state if ln not in present]
    if not state:
        return ("Windows Device Manager lists no camera device at all on the computer "
                "running this app, so Chrome and OpenCV have nothing to open here. That "
                "is a machine-level matter (BIOS camera option, privacy switch, or the "
                "camera module itself), not a bug in this app.")
    if present:
        return ("Windows does list a usable camera on this computer: " + "; ".join(present[:2]) +
                ". If a browser panel still shows nothing, check the browser's camera "
                "permission, close whatever else holds the camera, or remember that a "
                "visitor's browser uses the visitor's own camera.")
    return ("Windows knows this camera but reports it is not available right now: " +
            "; ".join(broken[:2]) + ". A status of Unknown with CM_PROB_PHANTOM (Code 45) "
            "means the device is not on the USB bus at this moment, so no program - not "
            "Chrome, not the Windows Camera app, not this app - can open it. Order to try, "
            "cheapest first: (1) in an Administrator terminal run 'pnputil /scan-devices', "
            "(2) shut down, unplug the charger and hold the power button 15 seconds, then "
            "boot, (3) check the BIOS camera option (F10 at boot, Built-in Device Options), "
            "(4) if it still never appears the module or its ribbon cable needs service. "
            "Meanwhile a phone browser or any USB webcam gives the app a real camera.")


def _camera_diagnostic(attempts):
    """Plain-English text for 'OpenCV got no frame', built from real results."""
    parts = ["Local camera: OpenCV got no picture (" + "; ".join(attempts) + ")."]

    # Two very different failures, said differently:
    #   "could not open"        -> OpenCV never got the device at all. With this
    #      OpenCV build on Windows its own message is "backend is generally
    #      available but can't be used to capture by index", i.e. a limit of the
    #      Python OpenCV wheel - it says NOTHING about the hardware.
    #   "opened but no frame"   -> the device was claimed but stayed silent,
    #      which usually means another app holds it or a driver/permission issue.
    if any("delivered no frame" in a for a in attempts):
        parts.append(
            "OpenCV reached the camera device but no picture came out - usually "
            "another app already holds it (Teams, Zoom, the Camera app) or a "
            "driver/permission problem. Close those and press Start again."
        )
    else:
        parts.append(
            "OpenCV could not even claim a camera slot here. That is often a limit "
            "of the OpenCV build inside this Python environment (it reports it "
            "cannot capture a camera by index number), NOT proof that this laptop "
            "has no camera. Mode A (the browser webcam) works without OpenCV."
        )

    devices = windows_camera_devices()
    if devices is None:
        parts.append("Windows device check unavailable here, so this says nothing about hardware.")
    elif not devices:
        parts.append(_camera_fault_line())
    else:
        parts.append(
            "Windows device check DOES see a camera (" + ", ".join(devices[:3]) + "), so it "
            "exists but this program could not use it - usually another app already holds it "
            "(Teams, Zoom, the Camera app) or it is a driver/permission problem. Close those "
            "and press Start again."
        )

    if os.getenv("SHARE_APP", "0") == "1":
        parts.append(
            "Remember: Start uses the camera of the computer running app.py. If you are on the "
            "shared link, use the browser webcam panel instead - the server cannot see your camera."
        )
    parts.append("Mode A (the browser webcam) and the video / photo uploads still work.")
    return " ".join(parts)


# --------------------------------------------------------------------------
# 2b) Mode B (server camera) and Mode C (video file)
# --------------------------------------------------------------------------
# There are three ways to feed the app, and only ONE should run at a time:
#   Mode A - the browser webcam panel (gr.Image sources=["webcam"]). The
#            browser asks permission and posts frames to this Python process.
#            This is the ONLY mode that can show the camera of the person
#            looking at the page, so it is the mode to use from a shared link.
#   Mode B - this class with source="camera": cv2.VideoCapture on the computer
#            that runs app.py. No browser permission needed, but it can only
#            ever see THAT machine's camera.
#   Mode C - this class with a video file path, for demos without any camera.
# A background thread keeps the NEWEST frame ready so the app always analyses
# the latest picture.
class LaptopCamera:
    def __init__(self):
        self.lock = threading.Lock()
        self.cam = None
        self.frame_rgb = None
        self.running = False
        self.is_clip = False     # True when playing a video file
        self.frame_delay = 0.0   # seconds to wait per clip frame

    def start(self, source="camera"):
        """Open the camera (source="camera") or a video file. Returns a
        plain-English status message."""
        if self.running:
            return "Video source: already running - press Stop first."
        if cv2 is None:
            return (
                "Local camera: unavailable because OpenCV (cv2) is not installed in "
                "this Python environment. The browser webcam and the photo/clip "
                "uploads still work."
            )

        self.is_clip = source != "camera"
        try:
            if self.is_clip:
                if not os.path.isfile(str(source)):
                    return "Clip: file not found - upload the video again."
                cam = cv2.VideoCapture(str(source))
                if not cam.isOpened():
                    cam.release()
                    return "Clip: that video file could not be opened (try an MP4)."
            else:
                cam, attempts = self._open_camera()
                if cam is None:
                    return _camera_diagnostic(attempts)

            with self.lock:
                self.cam, self.frame_rgb, self.running = cam, None, True
            if self.is_clip:
                fps = cam.get(cv2.CAP_PROP_FPS) or 25.0
                self.frame_delay = 1.0 / max(5.0, min(fps, 30.0))
            threading.Thread(target=self._read_loop, daemon=True).start()
            if self.is_clip:
                return "Clip: playing - the app reacts to the video like a live camera."
            return "Local camera: running - frames appear in 'What the app sees'."
        except Exception as e:
            # Anything unexpected: free the device so it is not left claimed.
            self.stop()
            return f"Local camera error: {type(e).__name__}: {e}"

    def _open_camera(self):
        """Try camera slots 0-2 with the two documented Windows backends.

        Returns (capture, attempts) where attempts is a plain list of what
        each try did, so the message can be honest instead of guessing.

        IMPORTANT: a camera is only considered working after it actually
        DELIVERS a frame. OpenCV's first read() right after open() often
        returns False even on a healthy camera (the sensor needs a few
        hundred ms to produce its first picture), so we retry before
        giving up - otherwise a working camera looks "missing".
        """
        backends = [("DirectShow", cv2.CAP_DSHOW)]
        if hasattr(cv2, "CAP_MSMF"):  # Media Foundation, the other Windows path
            backends.append(("Media Foundation", cv2.CAP_MSMF))

        attempts = []
        for index in (0, 1, 2):
            for label, api in backends:
                cam = None
                first_frame = None
                try:
                    cam = cv2.VideoCapture(index, api)
                    if cam.isOpened():
                        for _ in range(6):  # give the sensor ~1 s to produce a picture
                            ok, frame = cam.read()
                            if ok and frame is not None:
                                first_frame = frame
                                break
                            time.sleep(0.15)
                        attempts.append(
                            f"slot {index}/{label}: "
                            + ("delivered a frame" if first_frame is not None
                               else "opened but delivered no frame")
                        )
                    else:
                        attempts.append(f"slot {index}/{label}: could not open")
                except Exception as e:
                    attempts.append(f"slot {index}/{label}: {type(e).__name__}")

                if first_frame is not None:
                    print(f"[camera] using slot {index} ({label})")
                    return cam, attempts
                if cam is not None:  # never leave a device claimed
                    cam.release()
        return None, attempts

    def _read_loop(self):
        """Background thread: keep reading frames so they never go stale."""
        while self.running:
            with self.lock:
                cam = self.cam
            if cam is None:
                return
            ok, frame = cam.read()
            if not ok:
                if self.is_clip:
                    cam.set(cv2.CAP_PROP_POS_FRAMES, 0)  # loop the clip
                    time.sleep(0.1)
                else:
                    time.sleep(0.05)
                continue
            with self.lock:
                self.frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            if self.is_clip:
                time.sleep(self.frame_delay)  # play at the clip's own speed

    def latest_rgb(self):
        """The newest frame as an RGB numpy array (or None)."""
        with self.lock:
            return None if self.frame_rgb is None else self.frame_rgb.copy()

    def stop(self):
        self.running = False
        time.sleep(0.15)  # let the read loop finish its last read
        with self.lock:
            if self.cam is not None:
                self.cam.release()
                self.cam = None
            self.frame_rgb = None
            self.is_clip = False


server_cam = LaptopCamera()
atexit.register(server_cam.stop)  # release the camera when the app closes


# --------------------------------------------------------------------------
# 2c) Spoken callouts, synthesised in the background
# --------------------------------------------------------------------------
# Kokoro speech takes a few seconds per sentence on a normal CPU. If we
# waited for it inside the frame handler, the app would fall behind the
# camera again. So speech is made in ONE background worker; the frame
# handler just picks up each sentence once, as soon as it is ready.
_speech_executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
_speech_cache = {}    # message -> (sample_rate, samples) or None
_speech_pending = set()  # messages currently being synthesised
_speech_sent = set()     # messages already played (so we play each once)


def _request_speech(message):
    """Ask the background worker to synthesise this message (once)."""
    if message in _speech_cache or message in _speech_pending:
        return

    def _work():
        try:
            _speech_cache[message] = backend.speak(message, lang="en")
        except Exception as e:
            print(f"[speech] failed: {type(e).__name__}: {e}")
            _speech_cache[message] = None
        finally:
            _speech_pending.discard(message)

    _speech_pending.add(message)
    _speech_executor.submit(_work)

    # Keep the cache small: drop the oldest entries.
    while len(_speech_cache) > 40:
        oldest = next(iter(_speech_cache))
        _speech_cache.pop(oldest, None)
        _speech_sent.discard(oldest)


def _start_voice_warmup():
    """Load the Kokoro voice model right when the app starts.

    Without this, the FIRST spoken callout pays the whole model-loading
    cost (tens of seconds on a CPU) and the user hears nothing for the
    warning in front of them. We throw this practice sentence away.
    """
    def _warm():
        try:
            backend.speak("Sonar Vision voice check", lang="en")
            print("[speech] voice ready")
        except Exception as e:
            print(f"[speech] warm-up failed (voice still usable): "
                  f"{type(e).__name__}: {e}")

    threading.Thread(target=_warm, daemon=True).start()


_start_voice_warmup()


# --------------------------------------------------------------------------
# 3) The function that runs for every webcam frame (about twice a second)
# --------------------------------------------------------------------------
def live_sonar(frame):
    """Send one webcam frame to the backend and update the screen + sound.

    This function must NEVER crash - if the backend fails, we show the
    error in the Status box and keep running.
    """
    global _last_tone_key, _last_tone_time, last_logged_message

    if frame is None:
        # Don't log this - it would spam the log before the camera starts.
        return ("Mode A: the browser has not sent a camera frame yet - click the "
                "webcam panel and press Allow.",
                None, gr.update(), gr.update(), "\n".join(alert_log))

    try:
        result = backend.process_frame(frame)
        if not isinstance(result, dict) or "depth_vis" not in result:
            raise TypeError(
                "backend did not return the expected dictionary (missing 'depth_vis')"
            )

        level = str(result.get("level", "unknown")).upper()
        message = str(result.get("message", "")).strip()
        status = f"{level} - {message}" if message else level

        # ---- Tone: play when the situation changes, repeat warnings slowly ----
        zones = result.get("zones") or {}
        worst_zone = max(zones, key=zones.get) if zones else "center"
        tone_key = (result.get("level", ""), worst_zone)
        now = time.time()
        tone_out = gr.update()  # "leave the audio player as it is"
        if tone_key != _last_tone_key:
            tone_out = result.get("tone")  # new situation -> new tone
            _last_tone_key, _last_tone_time = tone_key, now
        elif result.get("level") in ("caution", "danger") and now - _last_tone_time >= TONE_REPEAT_S:
            tone_out = result.get("tone")  # keep warning while it lasts
            _last_tone_time = now

        # ---- Spoken callout: ask for speech on a NEW message, play it once ----
        spoken_out = gr.update()
        if message and message != last_logged_message:
            _request_speech(message)
        if message and message in _speech_cache and message not in _speech_sent:
            if _speech_cache[message] is not None:
                spoken_out = _speech_cache[message]
            _speech_sent.add(message)

        # Only write a log line when the message CHANGES - otherwise the
        # log would fill up with the same sentence twice a second.
        if message and message != last_logged_message:
            last_logged_message = message
            log_text = _append_log(status)
        else:
            log_text = "\n".join(alert_log)

        return (
            status,
            result.get("depth_vis"),
            tone_out,
            spoken_out,
            log_text,
        )

    except Exception as e:
        # Show a friendly error instead of crashing the stream.
        reason = f"{type(e).__name__}: {e}"
        print(f"[sonar] Backend problem: {reason}")
        status = f"BACKEND PROBLEM - stopped safely. {reason}"
        return status, None, gr.update(), gr.update(), _append_log(status)


# --------------------------------------------------------------------------
# 3b) Mode A (the viewer's browser webcam) - what the server can really see
# --------------------------------------------------------------------------
# The browser owns getUserMedia: it asks permission, opens the camera and
# POSTS pictures to this Python process. The server cannot hear Chrome say
# "permission denied" - it can only see whether frames arrive. So we count
# them, and the answer below reports exactly the state we can measure. Never
# a guess about anyone's hardware.
_mode_a_frames = 0          # how many camera frames any browser has sent us
_mode_a_last = 0.0          # time.time() of the most recent one


def live_sonar_from_webcam(frame):
    """The cam.stream handler: record the frame, then do the normal work."""
    global _mode_a_frames, _mode_a_last
    if frame is not None:
        _mode_a_frames += 1
        _mode_a_last = time.time()
    return live_sonar(frame)


def webcam_watchdog():
    """What the "Check my camera" button answers, from measured facts only.

    Permission-blocked and "your browser has no camera to offer" look
    identical from the server side (both send zero frames), so we name both
    possibilities instead of picking one.
    """
    now = time.time()
    if _mode_a_frames == 0:
        return ("Mode A: no camera frame has reached the app yet (0 so far). Click the "
                "webcam panel and choose Allow. If Chrome shows a blank panel or an "
                "error, your browser is refusing the camera - either permission is "
                "blocked, or no camera is available to the browser. This app cannot "
                "tell which, and it says nothing about anyone's hardware. "
                + _camera_fault_line())
    frames = f"{_mode_a_frames} frame" + ("s" if _mode_a_frames != 1 else "")
    age = now - _mode_a_last
    if age > 5:
        return (f"Mode A: {frames} arrived from the browser but none for {int(age)} "
                "seconds - the browser stopped sending them (panel closed, "
                "camera released, or this tab is in the background). Click the panel again "
                "and keep this tab in front.")
    return (f"Mode A is running: the browser is sending camera frames "
            f"({_mode_a_frames} so far, last one {age:.1f} s ago).")


# --------------------------------------------------------------------------
# 3c) The built-in demo: works with NO camera at all
# --------------------------------------------------------------------------
def _read_demo_photo_rgb():
    """Load the built-in demo photo as an RGB array, or None if that fails."""
    if cv2 is None or not DEMO_PHOTO.is_file():
        return None
    bgr = cv2.imread(str(DEMO_PHOTO))
    if bgr is None:
        return None
    return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)


def demo_run_photo():
    """One click: the REAL backend analyses the built-in photo.

    This writes only to the Demo tab's own components. The camera callbacks,
    the Stop button and TinyFish never touch them, so the cat picture and its
    sound cannot be cleared by anything else in the app.
    """
    if not DEMO_PHOTO.is_file():
        return ("DEMO FILE MISSING - put test_photo.jpg back in the project folder "
                "and restart the app.", gr.update(), gr.update(), gr.update())
    frame = _read_demo_photo_rgb()
    if frame is None:
        return ("DEMO COULD NOT READ test_photo.jpg (OpenCV is unavailable here, or the "
                "file is damaged).", gr.update(), gr.update(), gr.update())
    try:
        result = backend.process_frame(frame)
        level = str(result.get("level", "unknown")).upper()
        message = str(result.get("message", "")).strip()
        status = f"DEMO - prerecorded photo, not live detection - {level} - {message}"
        depth = result.get("depth_vis")
        tone = result.get("tone") or gr.update()
    except Exception as e:
        return (f"DEMO: the backend could not analyse the built-in photo - "
                f"{type(e).__name__}: {e}", gr.update(), gr.update(), gr.update())
    # The voice is made here (blocking) so one press gives tone AND words, and
    # the live camera's tone/voice bookkeeping is left completely alone.
    voice = None
    try:
        if message:
            voice = backend.speak(message, lang="en")
    except Exception as e:
        print(f"[demo] voice failed: {type(e).__name__}: {e}")
    return status, depth, tone, voice or gr.update()


# --------------------------------------------------------------------------
# 3d) "Ask about this place" - uses tinyfish_scout.py (search -> page -> cache)
# --------------------------------------------------------------------------
# The scout already does everything: find the site, read the page, pull the
# five accessibility facts, save the answer in cache/, and fall back to that
# saved answer if the network or the key fails.
try:
    import tinyfish_scout
    _scout_import_error = None
except Exception as e:
    tinyfish_scout = None
    _scout_import_error = f"{type(e).__name__}: {e}"


def _tinyfish_startup_note():
    """Honest line before anyone presses a button - no network call here."""
    if tinyfish_scout is None:
        return (f"**TinyFish status:** NOT AVAILABLE - tinyfish_scout.py could not load "
                f"({_scout_import_error}). The camera and the demo panel still work.")
    if not os.getenv("TINYFISH_API_KEY", "").strip():
        return ("**TinyFish status:** no API key in the environment, so a search can only "
                "use an answer already saved in cache/. Put your key after "
                "TINYFISH_API_KEY= in .env and restart for live lookups. "
                "(The key value is never shown anywhere.)")
    return ("**TinyFish status:** API key found in the environment. "
            "Press Ask TinyFish to make one real search. The key value is never shown.")


def run_tinyfish_lookup(place, page_url, use_agent):
    """Run the scout once and return (status, briefing, audio, progress log)."""
    if tinyfish_scout is None:
        return (f"**TinyFish status:** NOT AVAILABLE - tinyfish_scout.py could not load "
                f"({_scout_import_error}).", "*No briefing.*", gr.update(),
                "tinyfish_scout.py did not import.")

    steps, final, from_cache = [], None, False
    try:
        for upd in tinyfish_scout.scout_place(
                place,
                official_url=(page_url or "").strip() or None,
                use_agent=bool(use_agent)):
            stage = str(upd.get("stage", "?"))
            steps.append(f"[{stage}] {upd.get('message', '')}")
            if stage == "cache":
                from_cache = True
            if upd.get("data"):
                final = upd
    except Exception as e:
        steps.append(f"[error] the search crashed: {type(e).__name__}: {e}")
    progress = "\n".join(steps) if steps else "TinyFish returned nothing at all."

    if final is None:
        return ("**TinyFish test: FAILED** - no briefing could be made (see the progress "
                "box). The camera and the demo panel are unaffected.",
                "*No briefing.*", gr.update(), progress)

    data = final.get("data") or {}
    source = str(final.get("source", "?"))
    name = (place or "").strip()
    found = sum(1 for k in tinyfish_scout.FIELD_LABELS
                if data.get(k) and data[k] != "not stated")

    lines = [f"**Accessibility briefing - {name}**",
             f"Where it came from: {source}"
             + (" (a saved answer - the live lookup did not work)" if from_cache else ""),
             ""]
    for key, label in tinyfish_scout.FIELD_LABELS.items():
        lines.append(f"- **{label}:** {data.get(key) or 'not stated'}")
    briefing = "\n".join(lines)

    if from_cache:
        status = (f"**TinyFish test: worked from the saved answer** in cache/ "
                  f"(saved {final.get('cached_at', 'earlier')}); the live lookup failed. "
                  f"Fields found: {found}/5.")
    else:
        status = (f"**TinyFish test: LIVE search worked** - source {source}, "
                  f"{found} of 5 accessibility fields found, answer saved to cache/.")

    # Speak it with the same voice the sonar uses. Optional: if the voice fails,
    # the briefing text on screen still arrives.
    try:
        spoken = backend.speak(tinyfish_scout.to_briefing(name, data, source), lang="en")
    except Exception as e:
        print(f"[tinyfish] voice failed: {type(e).__name__}: {e}")
        spoken = None
    return status, briefing, (spoken or gr.update()), progress


# --------------------------------------------------------------------------
# 4) The screen
# --------------------------------------------------------------------------
# Big, high-contrast styling for the Status box (white on black) and an
# easy-to-read monospace alert log.
CUSTOM_CSS = """
#status-box textarea {
    background: #000000 !important;
    color: #ffffff !important;
    font-size: 2.4em !important;
    font-weight: 700 !important;
    text-align: center !important;
}
#alert-log textarea {
    font-family: monospace !important;
    font-size: 1.05em !important;
}
"""

with gr.Blocks(title="Sonar Vision") as demo:
    gr.Markdown(
        "# Sonar Vision\n"
        "Point the camera where you are walking. Green = far, red = close.\n\n"
        "**Prototype - not a certified navigation aid.**"
    )

    with gr.Tab("Live sonar"):
        status_box = gr.Textbox(
            label="Status",
            value="Mode A: click the webcam panel below and press Allow - it uses YOUR camera.",
            elem_id="status-box", interactive=False, max_lines=2,
        )
        gr.Markdown(
            "**Mode A - your browser webcam (the normal way, works for anyone who opens "
            "this page):** click the panel below, then press **Allow** in the browser "
            "pop-up. Frames go from your browser to the app. "
            "**Mode B - host camera only:** opens the camera attached to the computer "
            "running the Python app, never a visitor's camera. "
            "**Mode C - no camera:** upload a short video and press Play this clip. "
            "Use ONE mode at a time - starting Mode B or C hides the Mode A panel."
        )
        # Mode A first: it is the only mode a shared link can really use.
        cam = gr.Image(
            sources=["webcam"], streaming=True, type="numpy",
            label="Mode A: your browser webcam (click to start, Allow the prompt)",
            alt_text="Live webcam view of the space in front of you",
        )
        mode_a_check_btn = gr.Button(
            "Check my camera - has my browser sent any frames?", variant="secondary"
        )
        with gr.Row():
            start_cam_btn = gr.Button(
                "Mode B: camera attached to the computer running the Python app",
                variant="secondary",
            )
            stop_cam_btn = gr.Button("Stop Mode B / C", variant="stop")
        cam_status = gr.Markdown("Mode B / C are not running.")
        with gr.Row():
            clip_in = gr.Video(
                sources=["upload"],
                label="Mode C: upload a video of the space (MP4)",
            )
            play_clip_btn = gr.Button("Play this clip", variant="primary")
        with gr.Row():
            view_img = gr.Image(
                label="What the app sees (Mode B / Mode C)", interactive=False,
                alt_text="The exact frame the app is analysing right now",
            )
            depth_img = gr.Image(
                label="Depth view (green = far, red = close)",
                alt_text="Depth map: green areas are far away, red areas are close",
            )
        gr.Markdown(
            "**Four different problems, four different fixes.** 1) *Chrome asks for "
            "permission and you press Block* -> click the camera/lock icon at the LEFT of "
            "the address bar, set Camera to Allow, reload. 2) *Chrome says it cannot find "
            "a camera* -> your browser has no camera device to offer (close Teams/Zoom, "
            "check the laptop's camera cover or switch, or use Mode C). 3) *The panel "
            "started but the Status box says frames stopped* -> the browser released the "
            "camera; click the panel again. 4) *Mode B* never touches your camera - it "
            "only tries the camera of the machine running the Python app, and its message "
            "lists what it tried there. 5) *No camera anywhere on this computer* -> press "
            "**Check my camera** and it prints what Windows itself reports about the "
            "devices on the machine running the app. If Windows lists none, the fastest "
            "real-camera demo is to open the app link on a **phone** (the https://... "
            "gradio.live link): the phone's browser has its own camera and its frames go "
            "to the same backend."
        )
        with gr.Row():
            upload_img = gr.Image(
                sources=["upload"], type="numpy",
                label="Fallback: upload a photo (if no camera)",
                alt_text="Upload a photo of the space instead of using the webcam",
            )
            analyze_btn = gr.Button("Analyze this photo", variant="secondary")
        with gr.Row():
            tone_audio = gr.Audio(
                label="Sonar tone (stereo - panned towards the obstacle)",
                autoplay=True, format="wav",
            )
            speak_audio = gr.Audio(
                label="Spoken callout (voice)",
                autoplay=True, format="wav",
            )
        log_box = gr.Textbox(
            label="Spoken / alert log (last 10)",
            value=" ", lines=6, max_lines=10,
            elem_id="alert-log", interactive=False, autoscroll=True,
        )

    with gr.Tab("Demo / Prototype (no camera)"):
        gr.Markdown(
            "**Pre-recorded demo - not live detection.** This tab uses files that are "
            "already in the project folder, so it works even if every camera fails or a "
            "judge has no webcam. These pictures and players belong to this tab only: no "
            "camera button, no Stop press and no TinyFish search writes to them.\n\n"
            + _asset_warning()
        )
        with gr.Row():
            gr.Image(
                value=str(DEMO_PHOTO) if DEMO_PHOTO.is_file() else None,
                label="Built-in prototype photo (the cat)", interactive=False,
                alt_text="The cat photo shipped with this project",
            )
            gr.Video(
                value=str(DEMO_CLIP) if DEMO_CLIP.is_file() else None,
                label="Built-in demo clip (walking up to it)",
            )
        with gr.Row():
            demo_photo_btn = gr.Button(
                "Hear the demo: analyse the built-in photo", variant="primary")
            demo_clip_btn = gr.Button(
                "Play the built-in clip through the app", variant="secondary")
        demo_status = gr.Textbox(
            label="Demo result (prerecorded, not live)", interactive=False, max_lines=3)
        with gr.Row():
            demo_depth_img = gr.Image(
                label="Demo depth view (green = far, red = close)", interactive=False,
                alt_text="Depth map of the built-in demo photo")
            with gr.Column():
                demo_tone_audio = gr.Audio(
                    label="Demo sonar tone", autoplay=True, format="wav")
                demo_speak_audio = gr.Audio(
                    label="Demo spoken callout", autoplay=True, format="wav")
        gr.Markdown(
            "**Analysing the photo** runs the real backend on the built-in picture and "
            "plays the tone plus the spoken callout right here. **Playing the clip** runs "
            "the same frames through the app on the **Live sonar** tab - its status, depth "
            "and sound appear there, and **Stop Mode B / C** on that tab stops it."
        )

    with gr.Tab("Ask about this place (TinyFish)"):
        tf_status_md = gr.Markdown(_tinyfish_startup_note())
        with gr.Row():
            tf_place = gr.Textbox(
                label="Place name", value="John Rylands Library",
                info="Any venue, e.g. 'Manchester Central Library'.")
            tf_url = gr.Textbox(
                label="Its web page (optional)",
                info="Leave empty and the app searches for the official site.")
        tf_agent = gr.Checkbox(
            value=False,
            label="Also send a web agent (reads thin pages better, takes 30-60 s "
                  "and spends TinyFish credit)")
        tf_btn = gr.Button("Ask TinyFish", variant="primary")
        tf_briefing = gr.Markdown("*No briefing yet.*")
        tf_audio = gr.Audio(label="Spoken briefing", autoplay=True, format="wav")
        tf_log = gr.Textbox(
            label="What TinyFish did (progress)", lines=8, max_lines=20,
            interactive=False, autoscroll=True)
        gr.Markdown("Web information can be wrong or out of date - confirm before you "
                    "travel. A TinyFish failure never affects the camera or the demo tab.")

    with gr.Tab("About"):
        gr.Markdown(
            "**Built vs used**\n\n"
            "- **Used:** Depth Anything V2 Small (depth estimation), Kokoro "
            "(text to speech), Gradio (interface), TinyFish (web search + reading).\n"
            "- **Ours:** depth-to-sound mapping, spoken callouts, scout pipeline, "
            "caching, interface.\n\n"
            "**Limits:** this is a prototype. It has not been tested with blind "
            "or low-vision users. Information read from the web can be wrong or "
            "out of date."
        )

    # ---- The host camera / clip (Start switches the frame timer on) ----
    def _mode_result(message):
        """Status text + timer on/off + hide the Mode A panel while Mode B/C
        runs, so two camera systems are never feeding the app at once.
        (Gradio 6 only starts a gr.Timer after an update switches it on, which
        is why Mode A's check is a button instead of a background timer.)"""
        return (
            message,
            gr.Timer(active=server_cam.running),
            gr.update(visible=not server_cam.running),
        )

    def start_laptop_camera():
        return _mode_result(server_cam.start())

    def play_clip(path):
        return _mode_result(server_cam.start(source=path or "camera"))

    def stop_laptop_camera():
        server_cam.stop()
        # Also clear the players: a beep already queued must not keep
        # sounding after the user pressed Stop.
        return (
            "Mode B / C stopped - the host camera device was released and the tone "
            "and voice players were cleared. To stop Mode A, click the stop button "
            "on the webcam panel itself (only your browser can switch that camera off).",
            gr.Timer(active=False),
            gr.update(visible=True),
            None,
            None,
        )

    def laptop_camera_tick():
        """Runs on every timer tick while Mode B or C is on."""
        frame = server_cam.latest_rgb()
        if frame is None:
            # Camera still warming up - change nothing on screen.
            return (gr.update(), gr.update(), gr.update(),
                    gr.update(), gr.update(), gr.update())
        status, depth, tone, spoken, log = live_sonar(frame)
        return frame, status, depth, tone, spoken, log  # frame -> "What the app sees"

    def analyze_photo(frame):
        """Photo button: same as live_sonar, but waits for the background
        speech so the spoken callout arrives in ONE click. With the live
        camera this is not needed - the next frame picks it up."""
        outputs = list(live_sonar(frame))
        message = last_logged_message
        deadline = time.monotonic() + 60.0
        # First call can still be waiting for the voice model to load.
        while (message and message not in _speech_cache
               and time.monotonic() < deadline):
            time.sleep(0.25)
        if (message in _speech_cache and _speech_cache[message] is not None
                and message not in _speech_sent):
            outputs[3] = _speech_cache[message]
            _speech_sent.add(message)
        return tuple(outputs)

    server_timer = gr.Timer(0.5, active=False)
    start_cam_btn.click(start_laptop_camera, outputs=[cam_status, server_timer, cam])
    play_clip_btn.click(play_clip, inputs=clip_in, outputs=[cam_status, server_timer, cam])
    stop_cam_btn.click(
        stop_laptop_camera,
        outputs=[cam_status, server_timer, cam, tone_audio, speak_audio],
    )
    server_timer.tick(
        laptop_camera_tick,
        outputs=[view_img, status_box, depth_img, tone_audio, speak_audio, log_box],
        concurrency_limit=1,
        trigger_mode="always_last",
    )

    # Send every webcam frame to live_sonar, twice a second, for up to 1 hour.
    # trigger_mode="always_last" means: if frames queue up while one is still
    # processing, only the NEWEST frame is used - the screen never lags
    # behind the camera showing old results.
    cam.stream(
        live_sonar_from_webcam,
        inputs=cam,
        outputs=[status_box, depth_img, tone_audio, speak_audio, log_box],
        stream_every=0.5,
        time_limit=3600,
        concurrency_limit=1,
        trigger_mode="always_last",
    )
    # Uploaded photos (the no-camera fallback) go through the same function.
    analyze_btn.click(
        analyze_photo,
        inputs=upload_img,
        outputs=[status_box, depth_img, tone_audio, speak_audio, log_box],
    )
    # "Did my camera reach the app?" - answered from frame counts, not guesses.
    mode_a_check_btn.click(webcam_watchdog, outputs=status_box)

    # ---- Demo tab (its own components only) ----
    demo_photo_btn.click(
        demo_run_photo,
        outputs=[demo_status, demo_depth_img, demo_tone_audio, demo_speak_audio],
    )

    def play_builtin_clip():
        """Built-in clip through the same frame machinery as Mode C - but the
        file is already in the project folder, so nobody has to upload."""
        return _mode_result(server_cam.start(source=str(DEMO_CLIP)))

    demo_clip_btn.click(play_builtin_clip, outputs=[cam_status, server_timer, cam])

    # ---- TinyFish tab ----
    tf_btn.click(
        run_tinyfish_lookup,
        inputs=[tf_place, tf_url, tf_agent],
        outputs=[tf_status_md, tf_briefing, tf_audio, tf_log],
    )

# --------------------------------------------------------------------------
# 5) Start the web server
# --------------------------------------------------------------------------
if __name__ == "__main__":
    # SHARE_APP=1 in .env also publishes the app on a public
    # https://xxxx.gradio.live link you can send to a friend.
    # Leave it 0 and only this laptop can open the app.
    share = os.getenv("SHARE_APP", "0") == "1"
    if share:
        print("[share] SHARE_APP=1 -> the Public URL below is readable by ANYONE who has it.")

    # Render sets RENDER=true. A hosted app must listen on every interface and
    # use the port the platform gives it; it must not open a browser, and the
    # gradio.live tunnel is not needed because Render already supplies a URL.
    hosted = os.getenv("RENDER", "").strip().lower() in ("1", "true", "yes")
    port = int(os.getenv("PORT", "7860"))

    # PHONE_CAMERA=1 in .env serves the app over HTTPS on your home/college
    # Wi-Fi so a PHONE can be the camera. A browser only hands a web page the
    # camera when the page is https (or http://localhost), so the laptop's own
    # broken camera no longer matters - the phone's camera is used instead.
    # Gradio is then bound to 0.0.0.0, i.e. every network adapter on the laptop.
    phone_mode = os.getenv("PHONE_CAMERA", "0") == "1"
    launch_kwargs = {
        "server_port": port if hosted else 7860,
        "css": CUSTOM_CSS,
        "inbrowser": not hosted,
        "share": share and not hosted,
    }
    if hosted:
        launch_kwargs["server_name"] = "0.0.0.0"
        print(f"[hosted] listening on 0.0.0.0:{port}")
    elif phone_mode:
        import lan_cert

        cert, key = lan_cert.ensure_cert()
        if cert:
            launch_kwargs["server_name"] = "0.0.0.0"
            launch_kwargs["ssl_certfile"] = str(cert)
            launch_kwargs["ssl_keyfile"] = str(key)
            # Gradio makes an internal "did I start OK?" request to itself over
            # this same HTTPS port, and it verifies the certificate for it.
            # Our certificate is self-made (no certificate authority signs it), so
            # that self-check must not verify - ssl_verify=False only affects
            # Gradio talking to itself. It does NOT change the encrypted
            # connection your phone gets; the phone browser still shows its
            # usual warning that you accept once.
            launch_kwargs["ssl_verify"] = False
            print("\n" + "=" * 74)
            print("PHONE CAMERA MODE IS ON - this laptop is now the camera server.")
            print("1. Put the phone on the SAME Wi-Fi network as this laptop.")
            print("2. On the PHONE, open the address below in Chrome or Safari:")
            for url in lan_cert.phone_urls():
                print("      " + url)
            print("3. The browser warns the certificate is self-made - choose "
                  "\"Advanced\" then \"Continue\" (it is your own laptop, this is normal).")
            print("4. In the app press the browser-webcam Start button and ALLOW the "
                  "camera on the phone.")
            print("The frames are analysed on the laptop; the phone only supplies the camera.")
            print("=" * 74 + "\n")
        else:
            launch_kwargs["server_name"] = "127.0.0.1"
            print("[phone-camera] no certificate, falling back to local-only http://127.0.0.1:7860")
    else:
        launch_kwargs["server_name"] = "127.0.0.1"

    demo.launch(**launch_kwargs)
