"""lan_cert.py - makes a self-signed HTTPS certificate for THIS laptop.

Why this file exists
    A browser only gives a web page access to a camera when the page is
    served from https:// or from http://localhost. So to use a phone as the
    camera for this app, the phone must open https://<laptop-ip>:7860, and
    that needs a certificate that lists the laptop's current IP numbers.

What it does
    - Looks up this machine's IPv4 addresses (no network traffic leaves the
      laptop; the UDP trick below only asks the operating system which
      adapter it would use).
    - Writes certs/sonar_lan.pem + certs/sonar_lan.key with those addresses
      inside the certificate (the "subjectAltName" list browsers check).
    - Reuses the files while the addresses have not changed and they are
      younger than 12 hours, so restarting the app is fast.

It uses the `openssl` command-line tool if it is already installed. It never
installs anything, and it never reads or writes your TINYFISH_API_KEY.
"""

import shutil
import socket
import subprocess
import time
from pathlib import Path

CERT_DIR = Path(__file__).resolve().parent / "certs"
CERT = CERT_DIR / "sonar_lan.pem"
KEY = CERT_DIR / "sonar_lan.key"
SANS = CERT_DIR / "sonar_lan.addresses.txt"  # the addresses baked into the cert
DAYS = 30
MAX_AGE_HOURS = 12


def local_ipv4_addresses():
    """Return the IPv4 addresses this laptop is known by, sorted, no duplicates.

    Always contains 127.0.0.1 so the local machine can use https too.
    """
    found = {"127.0.0.1"}
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            found.add(info[4][0])
    except OSError:
        pass
    # Asking the OS which adapter it would route through reveals the live Wi-Fi
    # or Ethernet address. No packet is actually sent.
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("10.255.255.255", 1))
        found.add(probe.getsockname()[0])
    except OSError:
        pass
    finally:
        probe.close()
    return sorted(found)


def _openssl():
    """Find the openssl executable, or None if it is not installed."""
    return shutil.which("openssl")


def _addresses_match(addresses):
    """True if the saved certificate was made for exactly these addresses."""
    if not (CERT.is_file() and KEY.is_file() and SANS.is_file()):
        return False
    try:
        saved = SANS.read_text(encoding="utf-8").split()
    except OSError:
        return False
    if saved != list(addresses):
        return False
    age_hours = (time.time() - CERT.stat().st_mtime) / 3600
    return age_hours < MAX_AGE_HOURS


def ensure_cert(verbose=True):
    """Return (cert_path, key_path) ready for Gradio, or (None, None).

    Never raises: if anything is missing or fails, it prints why and returns
    (None, None) so the app can start as plain http on localhost instead.
    """
    try:
        addresses = local_ipv4_addresses()
        if _addresses_match(addresses):
            if verbose:
                print(f"[https] reusing the certificate in certs/ (addresses unchanged: {', '.join(addresses)})")
            return CERT, KEY

        exe = _openssl()
        if not exe:
            if verbose:
                print("[https] openssl is not installed, so no certificate can be made. "
                      "The app will start as plain http://127.0.0.1 - a phone cannot use its "
                      "camera against a plain http address that is not localhost.")
            return None, None

        CERT_DIR.mkdir(exist_ok=True)
        alt_names = ",".join(["IP:" + a for a in addresses] + ["DNS:localhost"])
        cmd = [
            exe, "req", "-x509", "-newkey", "rsa:2048", "-nodes",
            "-keyout", str(KEY), "-out", str(CERT), "-days", str(DAYS),
            "-subj", "/CN=Sonar Vision LAN",
            "-addext", f"subjectAltName={alt_names}",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            if verbose:
                print("[https] openssl failed: " + (result.stderr or "").strip()[:300])
            return None, None

        SANS.write_text(" ".join(addresses), encoding="utf-8")
        if verbose:
            print(f"[https] made a new self-signed certificate for: {', '.join(addresses)} "
                  f"(valid {DAYS} days)")
        return CERT, KEY
    except Exception as e:  # never let the certificate stop the app
        if verbose:
            print(f"[https] certificate step skipped because of an error: {type(e).__name__}: {e}")
        return None, None


def phone_urls(port=7860):
    """The addresses to type into a phone that is on the same Wi-Fi."""
    return [f"https://{a}:{port}" for a in local_ipv4_addresses() if a != "127.0.0.1"]


if __name__ == "__main__":
    cert, key = ensure_cert()
    print("addresses this laptop is known by:", ", ".join(local_ipv4_addresses()))
    if cert:
        print("certificate:", cert)
        print("type one of these into a phone on the same Wi-Fi:")
        for url in phone_urls():
            print("   ", url)
    else:
        print("NO certificate - the app can only serve http://127.0.0.1")
