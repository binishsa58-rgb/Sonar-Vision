"""Download the model files during the Render build.

The app loads YOLOv8n, Depth Anything V2 Small and Kokoro at startup. Doing the
downloads here means a visitor never waits for them, and the files live inside
the project folder (HF_HOME) so they survive for the life of the instance.
"""

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
os.environ.setdefault("HF_HOME", str(ROOT / ".cache" / "huggingface"))

DEPTH_MODEL = "depth-anything/Depth-Anything-V2-Small-hf"
YOLO_WEIGHTS = ROOT / "yolov8n.pt"


def main():
    if not YOLO_WEIGHTS.is_file():
        raise SystemExit(f"Missing {YOLO_WEIGHTS.name} in {ROOT}")

    from ultralytics import YOLO

    YOLO(str(YOLO_WEIGHTS))
    print(f"[prefetch] YOLO weights ready: {YOLO_WEIGHTS.name}")

    from transformers import pipeline

    pipeline("depth-estimation", model=DEPTH_MODEL)
    print(f"[prefetch] depth model ready: {DEPTH_MODEL}")

    try:
        from kokoro import KPipeline

        voice = KPipeline(lang_code="a")
        for _ in voice("Sonar Vision ready.", voice="af_heart"):
            pass
        print("[prefetch] Kokoro model and af_heart voice ready.")
    except Exception as e:
        # Speech is optional (the words still appear on screen), so do not
        # block the whole deployment if only this download fails.
        print(f"[prefetch] WARNING: Kokoro prefetch failed: {type(e).__name__}: {e}")


if __name__ == "__main__":
    main()
